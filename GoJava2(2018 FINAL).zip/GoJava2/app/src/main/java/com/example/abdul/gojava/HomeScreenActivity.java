package com.example.abdul.gojava;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.Toast;

public class HomeScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homescreen);
      ////////////TUTORIAL BUTTON/////////////////////////////////////
        Button bt1= findViewById(R.id.tutbtn);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                        //CODE TO BE EXECUTED AFTER TUTORIAL BUTTON CLICKED
                        Intent intent = new Intent(HomeScreenActivity.this,TopicActivity.class);
                        startActivity(intent);
            }
        });
        ////////////////////////PROGRAMS BUTTON//////////////////////////
        Button bt2= findViewById(R.id.prgbtn);
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(HomeScreenActivity.this,ProgramsActivity.class);
                startActivity(intent);
            }
        });
        //////////////////////IMP QUESTION BUTTON////////////////////////
        Button bt3=findViewById(R.id.quesbtn);
        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(HomeScreenActivity.this,ImpQuestionsActivity.class);
                startActivity(intent);
            }
        });
        ////////////////////QUIZ BUTTON///////////////////////////////////
        Button bt4=findViewById(R.id.quizbtn);

            bt4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent =new Intent(HomeScreenActivity.this,QuizActivity.class);
                    startActivity(intent);
                }
            });
        /////////////////ONLINE COMPILER BUTTON////////////////////////////////////////
        Button  bt5=findViewById(R.id.videobtn);
        bt5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.jdoodle.com/online-java-compiler"));
                startActivity(intent);

            }

        });

        /* //////////////////////SHARE BUTTON///////////////////////////////////////////////////////// */
        Button  bt6=findViewById(R.id.sharebtn);
        bt6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent= new Intent(android.content.Intent.ACTION_SEND);
                myIntent.setType("text/plain");
                String shareBody="Your Body Here";
                String share="Your Subject Here";
                myIntent.putExtra(Intent.EXTRA_SUBJECT,shareBody);
                myIntent.putExtra(Intent.EXTRA_SUBJECT,share);
                startActivity(Intent.createChooser(myIntent,"SHARE USING"));


            }

        });
    }

    ///////////////////////////INVOKED WHEN BACK BUTTON IS CLICKED FROM HOME SCREEN///////////////////////////////////////////
    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setMessage("Do you want to Exit?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //if user CLICKS "yes", then he is allowed to exit from application
                finish();
            }
        });
        builder.setNegativeButton("No",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //if user select "No", just cancel this dialog and continue with app
                dialog.cancel();
            }
        });
        AlertDialog alert=builder.create();
        alert.show();
    }

    //Options Menu


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
       getMenuInflater().inflate(R.menu.action_menu_main,menu);
       return  true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.about:
                Toast.makeText(this,"CONTACT:abdulshahid347@gmail.com",Toast.LENGTH_LONG).show();
                return true;
            case R.id.rate:
                ShowDialog();
                return  true;

        }
        return  true;
    }
    public void ShowDialog()
    {
        final AlertDialog.Builder popDialog = new AlertDialog.Builder(this);
        final RatingBar rating = new RatingBar(this);
        rating.setMax(5);
        popDialog.setIcon(android.R.drawable.btn_star_big_on);
        popDialog.setTitle("RATE IT!!!");
        popDialog.setView(rating);

// Button OK
        popDialog.setPositiveButton(android.R.string.ok,
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String cText=String.valueOf(rating.getProgress());
                        Toast.makeText(getApplicationContext(),cText,Toast.LENGTH_LONG).show();
                        dialog.dismiss();
                    }
                })
// Button Cancel
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
        popDialog.create();
        popDialog.show();
    }
}
