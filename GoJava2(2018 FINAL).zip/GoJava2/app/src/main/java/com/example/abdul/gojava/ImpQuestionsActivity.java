package com.example.abdul.gojava;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;

import com.example.abdul.gojava.database.AnswerDatabaseHelper;
import com.example.abdul.gojava.database.init.ContentLoader;

import java.util.ArrayList;
import java.util.List;

public class ImpQuestionsActivity extends AppCompatActivity {

    ExpandableListView expandableListView;
    List<String> Question = new ArrayList<>();
    ExpandableListAdapter listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_impquestions);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        expandableListView=findViewById(R.id.expandableListView);
        ContentLoader.qaFillData(Question);
        AnswerDatabaseHelper contentDbHelper=new AnswerDatabaseHelper(this);
        listAdapter=new MyExListAdapter(this, "IQ", Question, contentDbHelper);
        expandableListView.setAdapter(listAdapter);


    }


}
