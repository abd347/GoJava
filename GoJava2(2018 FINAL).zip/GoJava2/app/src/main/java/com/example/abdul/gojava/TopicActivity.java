package com.example.abdul.gojava;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;

import com.example.abdul.gojava.database.AnswerDatabaseHelper;
import com.example.abdul.gojava.database.init.ContentLoader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TopicActivity extends AppCompatActivity {
    ExpandableListView expandableListView;
    List<String> Chapter = new ArrayList<>();
    Map<String,List<String>> topics= new HashMap<>();
    ExpandableListAdapter listAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topic);
        getSupportActionBar().setDisplayShowHomeEnabled(true);//BACK BUTTON
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        expandableListView=findViewById(R.id.expandableListView);
        ContentLoader.topicFillData(Chapter,topics);
        listAdapter=new MyExtForTopicAdapter(this,Chapter, topics);
        expandableListView.setAdapter(listAdapter);
        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                Intent intent = new Intent(TopicActivity.this,TopicDisplayActivity.class);
                intent.putExtra("pageName", "topics");//CHANGE MADE HERE
                intent.putExtra("rowId", String.valueOf(groupPosition).concat("-").concat(String.valueOf(childPosition)));
                startActivity(intent);
                return true;
            }
        });
    }

}
