package com.example.abdul.gojava;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;

import com.example.abdul.gojava.database.AnswerDatabaseHelper;

public class TopicDisplayActivity extends AppCompatActivity {
    String sol;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topicdisplay);
        TextView tv=findViewById(R.id.tv);
        AnswerDatabaseHelper answerDatabaseHelper=new AnswerDatabaseHelper(this);
        sol=answerDatabaseHelper.getAnswer(getIntent().getExtras().get("pageName").toString(),
                getIntent().getExtras().get("rowId").toString());
        tv.setMovementMethod(new ScrollingMovementMethod());
        tv.setText(sol);

    }
}
