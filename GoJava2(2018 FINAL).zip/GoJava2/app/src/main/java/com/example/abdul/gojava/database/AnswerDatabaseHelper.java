package com.example.abdul.gojava.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.abdul.gojava.database.init.AnswerListBootstrap;
import com.example.abdul.gojava.database.models.Answers;

import java.util.Map;

public class AnswerDatabaseHelper extends SQLiteOpenHelper {
    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "goJava";

    public AnswerDatabaseHelper(Context context) {
        super(context,DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table answer_table ( page_name varchar(50), row_id varchar(50), data Text , primary key (page_name,row_id))");

        for (String pageName: AnswerListBootstrap.ANSWERS.keySet()) {//page names are the key set
            Map<String, String> rowMap = AnswerListBootstrap.ANSWERS.get(pageName);
            for (String rowId: rowMap.keySet()) {//page value ex 0-0 (row id's are keys for pages)
                insertAnswers(pageName, rowId, rowMap.get(rowId), db);
            }
        }

    }

    private void insertAnswers(String pageName, String rowId, String s, SQLiteDatabase db) {
        ContentValues values = new ContentValues();
        values.put(Answers.PAGE, pageName);
        values.put(Answers.ROW, rowId);
        values.put(Answers.ANSWER, s);


        // insertData row
        db.insert(Answers.TABLE_NAME, null, values);
    }

    public int getChildCount(String pageName, String parentPrefix) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select count(*) from answer_table where page_name='"+pageName+"' and row_id like '"+parentPrefix+"-%'", null);
        cursor.moveToFirst();
        int count = cursor.getInt(0);
        db.close();
        return count;
    }

    public String getAnswer(String pageName, String rowId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(Answers.TABLE_NAME,
                new String[]{Answers.PAGE, Answers.ROW, Answers.ANSWER},
                Answers.PAGE + "=? and " + Answers.ROW + "=?" ,
                new String[]{String.valueOf(pageName), String.valueOf(rowId)}, null, null, null, null);


        if (cursor != null)
            cursor.moveToFirst();

        // prepare Content object
        Answers answers = new Answers(
                cursor.getString(cursor.getColumnIndex(Answers.ROW)),
                cursor.getString(cursor.getColumnIndex(Answers.PAGE)),
                cursor.getString(cursor.getColumnIndex(Answers.ANSWER))
        );


        // close the db connection
        cursor.close();

        return answers.getAnswer();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + Answers.TABLE_NAME);

        // Create tables again
        onCreate(db);
    }
}
