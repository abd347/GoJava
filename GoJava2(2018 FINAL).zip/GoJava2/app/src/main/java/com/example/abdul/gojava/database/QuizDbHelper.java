package com.example.abdul.gojava.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


import com.example.abdul.gojava.database.models.Question;
import com.example.abdul.gojava.database.models.QuizContract.QuestionsTable;

import java.util.ArrayList;
import java.util.List;


public class QuizDbHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "Quiz.db";
    private static final int DATABASE_VERSION = 1;

    private SQLiteDatabase db;


    public QuizDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        this.db = db;

        final String SQL_CREATE_QUESTIONS_TABLE = "CREATE TABLE " +
                QuestionsTable.TABLE_NAME + " ( " +
                QuestionsTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionsTable.COLUMN_QUESTION + " TEXT, " +
                QuestionsTable.COLUMN_OPTION1 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION2 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION3 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION4 + " TEXT, " +
                QuestionsTable.COLUMN_ANSWER_NR + " INTEGER" +
                ")";

        db.execSQL(SQL_CREATE_QUESTIONS_TABLE);
        fillQuestionsTable();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + QuestionsTable.TABLE_NAME);
        onCreate(db);
    }

    private void fillQuestionsTable() {
        Question q1 = new Question("A process that involves recognizing and focusing on the important characteristics of a situation or object is known as:", "Encapsulation ", "Abstraction ", "Polymorphism", "Inheritance", 2);
        addQuestion(q1);
        Question q2 = new Question("Which statement is true regarding an object?", "An object is what classes instantiated are from", "An object is an instance of a class", "An object is a variable", "An object is a reference to an attribute", 2);
        addQuestion(q2);
        Question q3 = new Question("In object-oriented programming, composition relates to", "The use of consistent coding conventions", "The organization of components interacting to achieve a coherent, common behavior", "The use of inheritance to achieve polymorphic behavior", "The organization of components interacting not to achieve a coherent common behavior", 2);
        addQuestion(q3);
        Question q4 = new Question("In object-oriented programming, new classes can be defined by extending existing classes. This is an example of:", "Encapsulation", "Interface", "Composition", "Inheritance", 4);
        addQuestion(q4);
        Question q5 = new Question("Which of the following does not belong: If a class inherits from some other class, it should", "Make use of the parent class’s capabilities", "Over-ride or add the minimum to accomplish the derived class’ purpose", "Over-ride all the methods of its parent class", "Make sure the result “IS-A-KIND-OF” its base class", 3);
        addQuestion(q5);
        Question q6 = new Question("The wrapping up of data and functions into a single unit is called", "Encapsulation", "Abstraction", "Data Hiding", "Polymorphism", 1);
        addQuestion(q6);
        Question q7 = new Question("Given a class named student, which of the following is a valid constructor declaration for the class?", "Student (student s) { }", "Student student ( ) { }", "Private final student ( ) { }", "Void student ( ) { }", 1);
        addQuestion(q7);
        Question q8 = new Question("What is garbage collection in the context of Java?", "The operating system periodically deletes all of the java files available on the system.", "Any package imported in a program and not used is automatically deleted.", "When all references to an object are gone, the memory used by the object is automatically reclaimed.", "The JVM checks the output of any Java program and deletes anything that doesn’t make sense.", 3);
        addQuestion(q8);
        Question q9 = new Question("What is the error in the following class definitions?\nAbstract class xy\n{\nabstract sum (int x, int y) { }\n}", "Class header is not defined properly.", "Constructor is not defined.", "Method is not defined properly", "Method is defined properly", 3);
        addQuestion(q9);
        Question q10 = new Question("Which of these field declarations are legal within the body of an interface?", "Private final static int answer = 42", "public static int answer=42", "final static answer =42", "int answer", 2);
        addQuestion(q10);
        Question q11 = new Question("File class is included in which package?", "java.io package", "java.lang package", "java.awt package", "java.net.package", 1);
        addQuestion(q11);
        Question q12 = new Question("Which of the following events will cause a thread to die?", "The method sleep( ) is called", "The method wait( ) is called", "Execution of the start( ) method ends", "Execution of the run( ) method ends", 4);
        addQuestion(q12);
        Question q13 = new Question("Which of the following statements are true regarding the finalize( ) method?", "The finalize ( ) method must be declared with protected accessibility", "The compiler will fail to compile the code that explicitly tries to call the finalize( ) method", "The body of the finalize ( ) method can only access other objects that are eligible for garbage collection", "The finalize ( ) method can be overloaded", 4);
        addQuestion(q13);
        Question q14 = new Question("What will be the result of attempting to compile the following program?\npublic class MyClass {\nlong var;\npublic void MyClass(long param) { var = param; } //(1)\npublic static void main(String[] args) {\nMyClass a,b;\na = new MyClass(); //(2)\nb = new MyClass(5); //(3)\n}\n}", "A compilation ERROR will occur at (1), since constructors cannot specify a return value", "A compilation error will occur at (2), since the class does not have a default constructor", "A compilation error will occur at (3), since the class does not have a constructor which takes one argument of type int", "The program will compile correctly", 3);
        addQuestion(q14);
        Question q15 = new Question("What is the fundamental unit of information of writer streams?", "Characters", "Bytes", "Files", "Records", 1);
        addQuestion(q15);
    }

    private void addQuestion(Question question) {
        ContentValues cv = new ContentValues();
        cv.put(QuestionsTable.COLUMN_QUESTION, question.getQuestion());
        cv.put(QuestionsTable.COLUMN_OPTION1, question.getOption1());
        cv.put(QuestionsTable.COLUMN_OPTION2, question.getOption2());
        cv.put(QuestionsTable.COLUMN_OPTION3, question.getOption3());
        cv.put(QuestionsTable.COLUMN_OPTION4, question.getOption4());
        cv.put(QuestionsTable.COLUMN_ANSWER_NR, question.getAnswerNr());
        db.insert(QuestionsTable.TABLE_NAME, null, cv);
    }

    public List<Question> getAllQuestions() {
        List<Question> questionList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + QuestionsTable.TABLE_NAME, null);

        if (c.moveToFirst()) {
            do {
                Question question = new Question();
                question.setQuestion(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION)));
                question.setOption1(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION1)));
                question.setOption2(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION2)));
                question.setOption3(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION3)));
                question.setOption4(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION4)));
                question.setAnswerNr(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NR)));
                questionList.add(question);
            } while (c.moveToNext());
        }

        c.close();
        return questionList;
    }
}

