package com.example.abdul.gojava.database.init;

import java.util.HashMap;
import java.util.Map;

public class AnswerListBootstrap {
    public static final Map<String, Map<String, String>> ANSWERS = new HashMap<String, Map<String, String>>() {
        {
            put("IQ", new HashMap<String, String>(){{
                put("0-0", "Simple,Object-Oriented,Portable,Platform independent,Secured");
                put("1-0", "Byte code can run on any Architecture that is why it is call Architectural neutral, just you need JVM. It's compiler generates an architecture-neutral object file format, which makes the compiled code to be executable on many processors, with the presence of Java runtime system.");
                put("2-0", "It compiles the bytecode into platform-specific executable code that is immediately executed.");
                put("3-0", "A class is an entity that determines how an object will behave and what the object will contain. In other words, it is a blueprint or a set of instruction to build a specific type of object.");
                put("4-0", "With Java, you can compile source code on Windows and the compiled code (bytecode to be precise) can be executed (interpreted) on any platform running a JVM.");
                put("5-0", "Java is not because it supports Primitive datatype such as int, byte, long... etc, to be used, which are not objects.");
                put("6-0", "A constructor in Java is a block of code similar to a method that's called when an instance of an object is created.");
                put("7-0", "A singleton is a class that allows only a single instance of itself to be created and gives access to that created instance.");
                put("8-0", "Variables and methods marked static belong to the class rather than to any particular instance of the class. These can be used without having any instances of that class at all.");
                put("9-0", "Data encapsulation, also known as data hiding, is the mechanism whereby the implementation details of a class are kept hidden from the user. The user can only perform a restricted set of operations on the hidden members of the class by executing special functions commonly called methods.");
                put("10-0", " float and double datatype are used to represent floating point numbers in Java, a double data type is more precise than float. A double variable can provide precision up to 15 to 16 decimal points as compared to float precision of 6 to 7 decimal digits");
                put("11-0", "The switch and case keywords evaluate expression and execute any statement associated with constant-expression whose value matches the initial expression. If there is no match with a constant expression, the statement associated with the default keyword is executed.");
                put("12-0", "A base class is a class, in an object-oriented programming language, from which other classes are derived. It facilitates the creation of other classes that can reuse the code implicitly inherited from the base class (except constructors and destructors).");
                put("13-0", "NO");
                put("14-0", "It is empty, but not null.");
                put("15-0", "The program compiles and runs correctly because the order of specifiers doesn't matter in Java.");
                put("16-0", "The local variables are not initialized to any default value, neither primitives nor object references");
                put("17-0", "The Object is the real-time entity having some state and behavior. In Java, Object is an instance of the class having the instance variables as the state of the object and the methods as the behavior of the object. The object of a class can be created by using the new keyword.");
                put("18-0", "All object references are initialized to null in Java.");
                put("19-0", "Default Constructor,Parameterized Constructor");
                put("20-0", "The purpose of the default constructor is to assign the default value to the objects. The java compiler creates a default constructor implicitly if there is no constructor in the class.");
                put("21-0", "yes, The constructor implicitly returns the current instance of the class (You can't use an explicit return type with the constructor).");
                put("22-0", "NO");
                put("23-0", "Yes, the constructors can be overloaded by changing the number of arguments accepted by the constructor or by changing the data type of the parameters.");
                put("24-0", "A static method belongs to the class rather than the object. There is no need to create the object to call the static methods. A static method can access and change the value of the static variable.");
                put("25-0", "Because the object is not required to call the static method. If we make the main method non-static, JVM will have to create its object first and then call main() method which will lead to the extra memory allocation.");
                put("26-0", "Yes, one of the ways to execute the program without the main method is using static block.");
                put("27-0", "Static block is used to initialize the static data member. It is executed before the main method, at the time of classloading.");
                put("28-0", "Program compiles. However, at runtime, It throws an error NoSuchMethodError.");
                put("29-0", "As we know that the static context (method, block, or variable) belongs to the class, not the object. Since Constructors are invoked only when the object is created, there is no sense to make the constructors static. However, if you try to do so, the compiler will show the compiler error.");
                put("30-0", "In Java, if we make the abstract methods static, It will become the part of the class, and we can directly call it which is unnecessary. Calling an undefined method is completely useless therefore it is not allowed.");
                put("31-0", "The this keyword is a reference variable that refers to the current object. There are the various uses of this keyword in Java. It can be used to refer to current class properties such as instance methods, variable, constructors, etc. It can also be passed as an argument into the methods or constructors. It can also be returned from the method as the current class instance.");
                put("32-0", "No, this cannot be assigned to any value because it always points to the current class object and this is the final reference in Java. However, if we try to do so, the compiler error will be shown.");
                put("33-0", "Constructor chaining enables us to call one constructor from another constructor of the class with respect to the current class object. We can use this keyword to perform constructor chaining within the same class. Consider the following example which illustrates how can we use this keyword to achieve constructor chaining.");
                put("34-0", "Constructor chaining enables us to call one constructor from another constructor of the class with respect to the current class object. We can use this keyword to perform constructor chaining within the same class. Consider the following example which illustrates how can we use this keyword to achieve constructor chaining.");
                put("35-0", "The object class is the superclass of all other classes in Java.");
                put("36-0", "The super keyword in Java is a reference variable that is used to refer to the immediate parent class object. Whenever you create the instance of the subclass, an instance of the parent class is created implicitly which is referred by super reference variable. The super() is called in the class constructor implicitly by the compiler if there is no super or this.");
                put("37-0", "The object cloning is used to create the exact copy of an object. The clone() method of the Object class is used to clone an object. The java.lang.Cloneable interface must be implemented by the class whose object clone we want to create. If we don't implement Cloneable interface, clone() method generates CloneNotSupportedException.");
                put("38-0", "Method overloading is the polymorphism technique which allows us to create multiple methods with the same name but different signature. We can achieve method overloading in two ways.Changing the number of argumentsChanging the return type");
                put("39-0", "In Java, method overloading is not possible by changing the return type of the program due to avoid the ambiguity.");

            }});
////////////////////////////////////////////////<-----------------END OF IMP QUESTION UPLOAD------------------------------------->//////////////////////
            put("topics", new HashMap<String, String>(){{
                put("0-0", "Java is a programming language created by James Gosling from Sun Microsystems (Sun) in 1991. The target of Java is to write a program once and then run this program on multiple operating systems. The first publicly available version of Java (Java 1.0) was released in 1995. Sun Microsystems was acquired by the Oracle Corporation in 2010. Oracle has now the steermanship for Java. In 2006 Sun started to make Java available under the GNU General Public License (GPL). Oracle continues this project called OpenJDK.Over time new enhanced versions of Java have been released. The current version of Java is Java 1.8 which is also known as Java 8.Java is defined by a specification and consists of a programming language, a compiler, core libraries and a runtime (Java virtual machine) The Java runtime allows software developers to write program code in other languages than the Java programming language which still runs on the Java virtual machine. The Java platform is usually associated with the Java virtual machine and the Java core libraries.");
                put("0-1", "A list of most important features of Java language is given below.\n" +
                        "Java Features\n" +
                        "Simple\n" +
                        "Object-Oriented\n" +
                        "Portable\n" +
                        "Platform independent\n" +
                        "Secured\n" +
                        "Robust\n" +
                        "Architecture neutral\n" +
                        "Interpreted\n" +
                        "High Performance\n" +
                        "Multithreaded\n" +
                        "Distributed\n" +
                        "Dynamic");
                put("0-2", "Advantages of Java\n" +
                        "i. Simple\n" +
                        "Java was design to straightforward to use, write, compile, debug, and learn than alternative programming languages. Java is far less complicated than C++ as a result of Java uses automatic memory allocation and garbage collection.\n" +
                        "ii. Object-Oriented\n" +
                        "Permits you to form standard programs and reusable code.\n" +
                        "iii. Platform-Independent\n" +
                        "Ability to maneuver simply from one system to a different.\n" +
                        "iv. Distributed\n" +
                        "Designed to create distributed computing straightforward with the networking capability that’s inherently integrated into it.\n" +
                        "v. Secure\n" +
                        "The Java language focus on security, compiler, interpreter, and runtime surroundings were every develope.\n" +
                        "\n" +
                        "\n" +
                        "Disadvantages of Java\n" +
                        "i. Performance\n" +
                        "A lot of memory-consuming than natively compiled languages reminiscent of C or C++ and a bit slower.\n" +
                        "ii. Look and Feel\n" +
                        "The default look and feel of graphical user interface applications written in Java using the Swing toolkit are extremely completely different from native applications.\n" +
                        "iii. Single Paradigm Language\n" +
                        "Static imports were added in Java 5.0 the procedural paradigm is better accommodated than in earlier versions of Java.");
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                put("1-0", "Follow the instructions to download Java and run the .exe to install Java on your machine. Once you installed Java on your machine, you will need to set environment variables to point to correct installation directories −\n" +
                        "\n" +
                        "Setting Up the Path for Windows\n" +
                        " Assuming you have installed Java in c:\\Program Files\\java\\jdk directory −\n" +
                        "\n" +
                        "Right-click on 'My Computer' and select 'Properties'.\n" +
                        "\n" +
                        "Click the 'Environment variables' button under the 'Advanced' tab.\n" +
                        "\n" +
                        "Now, alter the 'Path' variable so that it also contains the path to the Java executable. Example, if the path is currently set to 'C:\\WINDOWS\\SYSTEM32', then change your path to read 'C:\\WINDOWS\\SYSTEM32;c:\\Program Files\\java\\jdk\\bin'.\n" +
                        "\n" +
                        "Setting Up the Path for Linux, UNIX, Solaris, FreeBSD\n" +
                        "Environment variable PATH should be set to point to where the Java binaries have been installed. Refer to your shell documentation, if you have trouble doing this.\n" +
                        "\n" +
                        "Example, if you use bash as your shell, then you would add the following line to the end of your '.bashrc: export PATH = /path/to/java:$PATH'\");\n");
                put("1-1","class Simple{  \n" +
                        "    public static void main(String args[]){  \n" +
                        "     System.out.println(\"Hello Java\");  \n" +
                        "    }  \n" +
                        "}  \n" +
                        "save this file as Simple.java\n" +
                        "\n" +
                        "To compile:\tjavac Simple.java\n" +
                        "To execute:\tjava Simple\n" +
                        "\n" +
                        "Let's see what is the meaning of class, public, static, void, main, String[], System.out.println().\n" +
                        "\n" +
                        "class keyword is used to declare a class in java.\n" +
                        "public keyword is an access modifier which represents visibility. It means it is visible to all.\n" +
                        "static is a keyword. If we declare any method as static, it is known as the static method. The core advantage of the static method is that there is no need to create an object to invoke the static method. The main method is executed by the JVM, so it doesn't require to create an object to invoke the main method. So it saves memory.\n" +
                        "void is the return type of the method. It means it doesn't return any value.\n" +
                        "main represents the starting point of the program.\n" +
                        "String[] args is used for command line argument. We will learn it later.\n" +
                        "System.out.println() is used print statement. We will learn about the internal working of System.out.println statement later.\"");
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                put("2-0", "A variable is a container which holds the value while the java program is executed. A variable is assigned with a datatype.\n" +
                        "\n" +
                        "Variable is a name of memory location. There are three types of variables in java: local, instance and static.\n" +
                        "\n" +
                        "There are two types of data types in java: primitive and non-primitive." +
                        "Variable is name of reserved area allocated in memory. In other words, it is a name of memory location. It is a combination of \"vary + able\" that means its value can be changed." +
                        "Types of Variables\n" +
                        "There are three types of variables in java:\n" +
                        "\n" +
                        "local variable\n" +
                        "instance variable\n" +
                        "static variable" +
                        "1) Local Variable\n" +
                        "A variable declared inside the body of the method is called local variable. You can use this variable only within that method and the other methods in the class aren't even aware that the variable exists.\n" +
                        "\n" +
                        "A local variable cannot be defined with \"static\" keyword.\n" +
                        "\n" +
                        "2) Instance Variable\n" +
                        "A variable declared inside the class but outside the body of the method, is called instance variable. It is not declared as static.\n" +
                        "\n" +
                        "It is called instance variable because its value is instance specific and is not shared among instances.\n" +
                        "\n" +
                        "3) Static variable\n" +
                        "A variable which is declared as static is called static variable. It cannot be local. You can create a single copy of static variable and share among all the instances of the class. Memory allocation for static variable happens only once when the class is loaded in the memory.");
                put("2-1", "Data types specify the different sizes and values that can be stored in the variable. There are two types of data types in Java:\n" +
                        "\n" +
                        "Primitive data types: The primitive data types include boolean, char, byte, short, int, long, float and double.\n" +
                        "Non-primitive data types: The non-primitive data types include Classes, Interfaces, and Arrays." +
                        "here are 8 types of primitive data types:\n" +
                        "\n" +
                        "boolean data type\n" +
                        "byte data type\n" +
                        "char data type\n" +
                        "short data type\n" +
                        "int data type\n" +
                        "long data type\n" +
                        "float data type\n" +
                        "double data type" +
                        "Data Type\tDefault Value\tDefault size\n" +
                        "boolean\tfalse\t1 bit\n" +
                        "char\t'\\u0000'\t2 byte\n" +
                        "byte\t0\t1 byte\n" +
                        "short\t0\t2 byte\n" +
                        "int\t0\t4 byte\n" +
                        "long\t0L\t8 byte\n" +
                        "float\t0.0f\t4 byte\n" +
                        "double\t0.0d\t8 byte");
                put("2-2", "The scope of a variable defines the section of the code in which the variable is visible. As a general rule, variables that are defined within a block are not accessible outside that block. The lifetime of a variable refers to how long the variable exists before it is destroyed. Destroying variables refers to deallocating the memory that was allotted to the variables when declaring it. We have written a few classes till now. You might have observed that not all variables are the same. The ones declared in the body of a method were different from those that were declared in the class itself. There are there types of variables: instance variables, formal parameters or local variables and local variables. \n" +
                        "\n" +
                        "Instance variables \n" +
                        "Instance variables are those that are defined within a class itself and not in any method or constructor of the class. They are known as instance variables because every instance of the class (object) contains a copy of these variables. The scope of instance variables is determined by the access specifier that is applied to these variables. We have already seen about it earlier. The lifetime of these variables is the same as the lifetime of the object to which it belongs. Object once created do not exist for ever. They are destroyed by the garbage collector of Java when there are no more reference to that object. We shall see about Java's automatic garbage collector later on. \n" +
                        "\n" +
                        "Argument variables \n" +
                        "These are the variables that are defined in the header oaf constructor or a method. The scope of these variables is the method or constructor in which they are defined. The lifetime is limited to the time for which the method keeps executing. Once the method finishes execution, these variables are destroyed. \n" +
                        "\n" +
                        "Local variables \n" +
                        "A local variable is the one that is declared within a method or a constructor (not in the header). The scope and lifetime are limited to the method itself. \n" +
                        "\n" +
                        "One important distinction between these three types of variables is that access specifiers can be applied to instance variables only and not to argument or local variables. \n" +
                        "\n" +
                        "In addition to the local variables defined in a method, we also have variables that are defined in bocks life an if block and an else block. The scope and is the same as that of the block itself. ");
                put("2-3", "Type Casting in Java\n" +
                        "Type casting is used to convert an object or variable of one type into another.\n" +
                        "\n" +
                        "\n" +
                        "Syntax\n" +
                        "dataType variableName = (dataType) variableToConvert;\n" +
                        "\n" +
                        "Notes\n" +
                        "There are two casting directions: narrowing (larger to smaller type) and widening (smaller to larger type). Widening can be done automatically (for example, int to double), but narrowing must be done explicitly (like double to int).\n" +
                        "\n" +
                        "\n" +
                        "Example\n" +
                        "double calculatedMark = 87.6;\n" +
                        "int finalGrade = (int)calculatedMark;");
                //////////////////////////////////////////////////////////////////////////////////////////////
                put("3-0", "Operator in java is a symbol that is used to perform operations. For example: +, -, *, / etc.\n" +
                        "\n" +
                        "There are many types of operators in java which are given below:\n" +
                        "\n" +
                        "Unary Operator,\n" +
                        "Arithmetic Operator,\n" +
                        "Shift Operator,\n" +
                        "Relational Operator,\n" +
                        "Bitwise Operator,\n" +
                        "Logical Operator,\n" +
                        "Ternary Operator and\n" +
                        "Assignment Operator.\n" +
                        "Java Operator Precedence\n" +
                        "Operator Type\tCategory\tPrecedence\n" +
                        "Unary\tpostfix\texpr++ expr--\n" +
                        "prefix\t++expr --expr +expr -expr ~ !\n" +
                        "Arithmetic\tmultiplicative\t* / %\n" +
                        "additive\t+ -\n" +
                        "Shift\tshift\t<< >> >>>\n" +
                        "Relational\tcomparison\t< > <= >= instanceof\n" +
                        "equality\t== !=\n" +
                        "Bitwise\tbitwise AND\t&\n" +
                        "bitwise exclusive OR\t^\n" +
                        "bitwise inclusive OR\t|\n" +
                        "Logical\tlogical AND\t&&\n" +
                        "logical OR\t||\n" +
                        "Ternary\tternary\t? :\n" +
                        "Assignment\tassignment\t= += -= *= /= %= &= ^= |= <<= >>= >>>=\n");
                put("3-1", "An expression is a statement that can convey a value. Some of the most common expressions are mathematical, such as in the following source code example:\n" +
                        "\n" +
                        "int x = 3;\n" +
                        "int y = x;\n" +
                        "int z = x * y;\n" +
                        "All three of these statements can be considered expressions—they convey values that can be assigned to variables. The first assigns the literal 3 to the variable x. The second assigns the value of the variable x to the variable y. The multiplication operator * is used to multiply the x and y integers, and the expression produces the result of the multiplication. This result is stored in the z integer.\n" +
                        "\n" +
                        "An expression can be any combination of variables, literals, and operators. They also can be method calls, because methods can send back a value to the object or class that called the method.\n" +
                        "\n" +
                        "The value conveyed by an expression is called a return value, as you have learned. This value can be assigned to a variable and used in many other ways in your Java programs.");
                put("3-2", "When more than one operator is used in an expression, Java has an established precedence to determine the order in which operators are evaluated. In many cases, this precedence determines the overall value of the expression.\n" +
                        "\n" +
                        "For example, consider the following expression:\n" +
                        "\n" +
                        "y = 6 + 4 / 2;\n" +
                        "The y variable receives the value 5 or the value 8, depending on which arithmetic operation is handled first. If the 6 + 4 expression comes first, y has the value of 5. Otherwise, y equals 8.\n" +
                        "\n" +
                        "In general, the order from first to last is the following:\n" +
                        "\n" +
                        "Increment and decrement operations\n" +
                        "\n" +
                        "Arithmetic operations\n" +
                        "\n" +
                        "Comparisons\n" +
                        "\n" +
                        "Logical operations\n" +
                        "\n" +
                        "Assignment expressions\n" +
                        "\n" +
                        "If two operations have the same precedence, the one on the left in the actual expression is handled before the one on the right. " +
                        "Operator\n" +
                        "\n" +
                        "Notes\n" +
                        "\n" +
                        ". [ ] ()\n" +
                        "\n" +
                        "Parentheses (()) are used to group expressions; period (.) is used for access to methods and variables within objects and classes (discussed tomorrow); square brackets ([ ]) are used for arrays. (This operator is discussed later in the week.)\n" +
                        "\n" +
                        "++ -- ! ~ instanceof\n" +
                        "\n" +
                        "The instanceof operator returns true or false based on whether the object is an instance of the named class or any of that class's subclasses (discussed tomorrow).\n" +
                        "\n" +
                        "new (type)expression\n" +
                        "\n" +
                        "The new operator is used for creating new instances of classes; () in this case is for casting a value to another type. (You learn about both of these tomorrow.)\n" +
                        "\n" +
                        "* / %\n" +
                        "\n" +
                        "Multiplication, division, modulus.\n" +
                        "\n" +
                        "+ -\n" +
                        "\n" +
                        "Addition, subtraction.\n" +
                        "\n" +
                        "<< >> >>>\n" +
                        "\n" +
                        "Bitwise left and right shift.\n" +
                        "\n" +
                        "< > <= >=\n" +
                        "\n" +
                        "Relational comparison tests.\n" +
                        "\n" +
                        "== !=\n" +
                        "\n" +
                        "Equality.\n" +
                        "\n" +
                        "&\n" +
                        "\n" +
                        "AND\n" +
                        "\n" +
                        "^\n" +
                        "\n" +
                        "XOR\n" +
                        "\n" +
                        "|\n" +
                        "\n" +
                        "OR\n" +
                        "\n" +
                        "&&\n" +
                        "\n" +
                        "Logical AND\n" +
                        "\n" +
                        "||\n" +
                        "\n" +
                        "Logical OR\n" +
                        "\n" +
                        "? :\n" +
                        "\n" +
                        "Shorthand for if...then...else (discussed on Day 5).\n" +
                        "\n" +
                        "= += -= *= /= %= ^=\n" +
                        "\n" +
                        "Various assignments.\n" +
                        "\n" +
                        "&= |= <<= >>= >>>=\n" +
                        "\n" +
                        "More assignments.\n" +
                        "\n");
                //////////////////////////////////////////////////////////////////////
                put("4-0", "The Java if statement tests the condition. It executes the if block if condition is true.\n" +
                        "\n" +
                        "Syntax:\n" +
                        "\n" +
                        "if(condition){  \n" +
                        "//code to be executed  \n" +
                        "}  \n" +
                        "if statement in java\n" +
                        "Example:\n" +
                        "\n" +
                        "//Java Program to demonstate the use of if statement.  \n" +
                        "public class IfExample {  \n" +
                        "public static void main(String[] args) {  \n" +
                        "    //defining an 'age' variable  \n" +
                        "    int age=20;  \n" +
                        "    //checking the age  \n" +
                        "    if(age>18){  \n" +
                        "        System.out.print(\"Age is greater than 18\");  \n" +
                        "    }  \n" +
                        "}  \n" +
                        "}  ");
                put("4-1", "The Java switch statement executes one statement from multiple conditions. It is like if-else-if ladder statement. The switch statement works with byte, short, int, long, enum types, String and some wrapper types like Byte, Short, Int, and Long. Since Java 7, you can use strings in the switch statement.\n" +
                        "\n" +
                        "In other words, the switch statement tests the equality of a variable against multiple values.\n" +
                        "\n" +
                        "Points to Remember\n" +
                        "There can be one or N number of case values for a switch expression.\n" +
                        "The case value must be of switch expression type only. The case value must be literal or constant. It doesn't allow variables.\n" +
                        "The case values must be unique. In case of duplicate value, it renders compile-time error.\n" +
                        "The Java switch expression must be of byte, short, int, long (with its Wrapper type), enums and string.\n" +
                        "Each case statement can have a break statement which is optional. When control reaches to the break statement, it jumps the control after the switch expression. If a break statement is not found, it executes the next case.\n" +
                        "The case value can have a default label which is optional.\n" +
                        "Syntax:\n" +
                        "\n" +
                        "switch(expression){    \n" +
                        "case value1:    \n" +
                        " //code to be executed;    \n" +
                        " break;  //optional  \n" +
                        "case value2:    \n" +
                        " //code to be executed;    \n" +
                        " break;  //optional  \n" +
                        "......    \n" +
                        "    \n" +
                        "default:     \n" +
                        " code to be executed if all cases are not matched;    \n" +
                        "}    ");
                put("4-2", "The Java while loop is used to iterate a part of the program several times. If the number of iteration is not fixed, it is recommended to use while loop.\n" +
                        "\n" +
                        "Syntax:\n" +
                        "\n" +
                        "while(condition){  \n" +
                        "//code to be executed  \n" +
                        "}  \n" +
                        "flowchart of java while loop\n" +
                        "Example:\n" +
                        "\n" +
                        "public class WhileExample {  \n" +
                        "public static void main(String[] args) {  \n" +
                        "    int i=1;  \n" +
                        "    while(i<=10){  \n" +
                        "        System.out.println(i);  \n" +
                        "    i++;  \n" +
                        "    }  \n" +
                        "}  \n" +
                        "}  ");
                put("4-3", "The Java do-while loop is used to iterate a part of the program several times. If the number of iteration is not fixed and you must have to execute the loop at least once, it is recommended to use do-while loop.\n" +
                        "\n" +
                        "The Java do-while loop is executed at least once because condition is checked after loop body.\n" +
                        "\n" +
                        "Syntax:\n" +
                        "\n" +
                        "do{  \n" +
                        "//code to be executed  \n" +
                        "}while(condition);  \n" +
                        "flowchart of do while loop in java\n" +
                        "Example:\n" +
                        "\n" +
                        "public class DoWhileExample {  \n" +
                        "public static void main(String[] args) {  \n" +
                        "    int i=1;  \n" +
                        "    do{  \n" +
                        "        System.out.println(i);  \n" +
                        "    i++;  \n" +
                        "    }while(i<=10);  \n" +
                        "}  \n" +
                        "}  ");
                put("4-4", "The Java for loop is used to iterate a part of the program several times. If the number of iteration is fixed, it is recommended to use for loop.\n" +
                        "\n" +
                        "There are three types of for loops in java.\n" +
                        "\n" +
                        "Simple For Loop\n" +
                        "For-each or Enhanced For Loop\n" +
                        "Labeled For Loop\n" +
                        "Java Simple For Loop\n" +
                        "A simple for loop is the same as C/C++. We can initialize the variable, check condition and increment/decrement value. It consists of four parts:\n" +
                        "\n" +
                        "Initialization: It is the initial condition which is executed once when the loop starts. Here, we can initialize the variable, or we can use an already initialized variable. It is an optional condition.\n" +
                        "Condition: It is the second condition which is executed each time to test the condition of the loop. It continues execution until the condition is false. It must return boolean value either true or false. It is an optional condition.\n" +
                        "Statement: The statement of the loop is executed each time until the second condition is false.\n" +
                        "Increment/Decrement: It increments or decrements the variable value. It is an optional condition.\n" +
                        "Syntax:\n" +
                        "\n" +
                        "for(initialization;condition;incr/decr){  \n" +
                        "//statement or code to be executed  \n" +
                        "}  ");

                //////////////////////////////////////////////////////////////////////////////////////////////////////
                put("5-0", "A class is a blueprint from which individual objects are created.\n" +
                        "\n" +
                        "Following is a sample of a class.\n" +
                        "\n" +
                        "Example\n" +
                        "public class Dog {\n" +
                        "   String breed;\n" +
                        "   int age;\n" +
                        "   String color;\n" +
                        "\n" +
                        "   void barking() {\n" +
                        "   }\n" +
                        "\n" +
                        "   void hungry() {\n" +
                        "   }\n" +
                        "\n" +
                        "   void sleeping() {\n" +
                        "   }\n" +
                        "}\n" +
                        "A class can contain any of the following variable types.\n" +
                        "\n" +
                        "Local variables − Variables defined inside methods, constructors or blocks are called local variables. The variable will be declared and initialized within the method and the variable will be destroyed when the method has completed.\n" +
                        "\n" +
                        "Instance variables − Instance variables are variables within a class but outside any method. These variables are initialized when the class is instantiated. Instance variables can be accessed from inside any method, constructor or blocks of that particular class.\n" +
                        "\n" +
                        "Class variables − Class variables are variables declared within a class, outside any method, with the static keyword.\n" +
                        "\n" +
                        "A class can have any number of methods to access the value of various kinds of methods. In the above example, barking(), hungry() and sleeping() are methods.");
                put("5-1", "Objects in Java\n" +
                        "Let us now look deep into what are objects. If we consider the real-world, we can find many objects around us, cars, dogs, humans, etc. All these objects have a state and a behavior.\n" +
                        "\n" +
                        "If we consider a dog, then its state is - name, breed, color, and the behavior is - barking, wagging the tail, running.\n" +
                        "\n" +
                        "If you compare the software object with a real-world object, they have very similar characteristics.\n" +
                        "\n" +
                        "Software objects also have a state and a behavior. A software object's state is stored in fields and behavior is shown via methods.\n" +
                        "\n" +
                        "So in software development, methods operate on the internal state of an object and the object-to-object communication is done via methods." +
                        "Creating an Object\n" +
                        "As mentioned previously, a class provides the blueprints for objects. So basically, an object is created from a class. In Java, the new keyword is used to create new objects.\n" +
                        "\n" +
                        "There are three steps when creating an object from a class −\n" +
                        "\n" +
                        "Declaration − A variable declaration with a variable name with an object type.\n" +
                        "\n" +
                        "Instantiation − The 'new' keyword is used to create the object.\n" +
                        "\n" +
                        "Initialization − The 'new' keyword is followed by a call to a constructor. This call initializes the new object.\n" +
                        "\n" +
                        "Following is an example of creating an object −\n" +
                        "\n" +
                        "Example\n" +
                        " Live Demo\n" +
                        "public class Puppy {\n" +
                        "   public Puppy(String name) {\n" +
                        "      // This constructor has one parameter, name.\n" +
                        "      System.out.println(\"Passed Name is :\" + name );\n" +
                        "   }\n" +
                        "\n" +
                        "   public static void main(String []args) {\n" +
                        "      // Following statement would create an object myPuppy\n" +
                        "      Puppy myPuppy = new Puppy( \"tommy\" );\n" +
                        "   }\n" +
                        "}\n" +
                        "If we compile and run the above program, then it will produce the following result −\n" +
                        "\n" +
                        "Output\n" +
                        "Passed Name is :tommy");
                put("5-2", "When discussing about classes, one of the most important sub topic would be constructors. Every class has a constructor. If we do not explicitly write a constructor for a class, the Java compiler builds a default constructor for that class.\n" +
                        "\n" +
                        "Each time a new object is created, at least one constructor will be invoked. The main rule of constructors is that they should have the same name as the class. A class can have more than one constructor.\n" +
                        "\n" +
                        "Following is an example of a constructor −\n" +
                        "\n" +
                        "Example\n" +
                        "public class Puppy {\n" +
                        "   public Puppy() {\n" +
                        "   }\n" +
                        "\n" +
                        "   public Puppy(String name) {\n" +
                        "      // This constructor has one parameter, name.\n" +
                        "   }\n" +
                        "}\n" +
                        "Java also supports Singleton Classes where you would be able to create only one instance of a class.\n" +
                        "\n" +
                        "Note − We have two different types of constructors. We are going to discuss constructors in detail in the subsequent chapters.");
                put("5-3", "Method Overloading in Java" +
                        "If a class has multiple methods having same name but different in parameters, it is known as Method Overloading.\n" +
                        "\n" +
                        "If we have to perform only one operation, having same name of the methods increases the readability of the program.\n" +
                        "\n" +
                        "Suppose you have to perform addition of the given numbers but there can be any number of arguments, if you write the method such as a(int,int) for two parameters, and b(int,int,int) for three parameters then it may be difficult for you as well as other programmers to understand the behavior of the method because its name differs.\n" +
                        "\n" +
                        "So, we perform method overloading to figure out the program quickly.\n" +
                        "\n" +
                        "java method overloading\n" +
                        "Advantage of method overloading\n" +
                        "Method overloading increases the readability of the program.\n" +
                        "\n" +
                        "Different ways to overload the method\n" +
                        "There are two ways to overload the method in java\n" +
                        "\n" +
                        "1:By changing number of arguments\n" +
                        "2:By changing the data type\n" +
                        "In java, Method Overloading is not possible by changing the return type of the method only.\n" +
                        "\n" +
                        " \n" +
                        "1) Method Overloading: changing no. of arguments\n" +
                        "In this example, we have created two methods, first add() method performs addition of two numbers and second add method performs addition of three numbers.\n" +
                        "\n" +
                        "In this example, we are creating static methods so that we don't need to create instance for calling methods.\n" +
                        "\n" +
                        "class Adder{  \n" +
                        "static int add(int a,int b){return a+b;}  \n" +
                        "static int add(int a,int b,int c){return a+b+c;}  \n" +
                        "}  \n" +
                        "class TestOverloading1{  \n" +
                        "public static void main(String[] args){  \n" +
                        "System.out.println(Adder.add(11,11));  \n" +
                        "System.out.println(Adder.add(11,11,11));  \n" +
                        "}} " +
                        "Output:\n" +
                        "\n" +
                        "22\n" +
                        "33 ");
                put("5-4","Method Overriding in Java" +
                        "If subclass (child class) has the same method as declared in the parent class, it is known as method overriding in Java.\n" +
                        "\n" +
                        "In other words, If a subclass provides the specific implementation of the method that has been declared by one of its parent class, it is known as method overriding.\n" +
                        "\n" +
                        "Usage of Java Method Overriding\n" +
                        "Method overriding is used to provide the specific implementation of a method which is already provided by its superclass.\n" +
                        "Method overriding is used for runtime polymorphism\n" +
                        "Rules for Java Method Overriding\n" +
                        "The method must have the same name as in the parent class\n" +
                        "The method must have the same parameter as in the parent class.\n" +
                        "There must be an IS-A relationship (inheritance)." +
                        "Example of method overriding\n" +
                        "In this example, we have defined the run method in the subclass as defined in the parent class but it has some specific implementation. The name and parameter of the method are the same, and there is IS-A relationship between the classes, so there is method overriding.\n" +
                        "\n" +
                        "//Java Program to illustrate the use of Java Method Overriding  \n" +
                        "//Creating a parent class.  \n" +
                        "class Vehicle{  \n" +
                        "  //defining a method  \n" +
                        "  void run(){System.out.println(\"Vehicle is running\");}  \n" +
                        "}  \n" +
                        "//Creating a child class  \n" +
                        "class Bike2 extends Vehicle{  \n" +
                        "  //defining the same method as in the parent class  \n" +
                        "  void run(){System.out.println(\"Bike is running safely\");}  \n" +
                        "  \n" +
                        "  public static void main(String args[]){  \n" +
                        "  Bike2 obj = new Bike2();//creating object  \n" +
                        "  obj.run();//calling method  \n" +
                        "  }  \n" +
                        "}  \n" +
                        "Output:\n" +
                        "\n" +
                        "Bike is running safely");
                put("5-5", "The static keyword in Java is used for memory management mainly. We can apply java static keyword with variables, methods, blocks and nested class. The static keyword belongs to the class than an instance of the class.\n" +
                        "\n" +
                        "The static can be:\n" +
                        "\n" +
                        "Variable (also known as a class variable)\n" +
                        "Method (also known as a class method)\n" +
                        "Block\n" +
                        "Nested class\n" +
                        "Static in Java\n" +
                        "1) Java static variable\n" +
                        "If you declare any variable as static, it is known as a static variable.\n" +
                        "\n" +
                        "The static variable can be used to refer to the common property of all objects (which is not unique for each object), for example, the company name of employees, college name of students, etc.\n" +
                        "The static variable gets memory only once in the class area at the time of class loading.\n" +
                        "Advantages of static variable\n" +
                        "It makes your program memory efficient (i.e., it saves memory).\n" +
                        "\n" +
                        "Understanding the problem without static variable\n" +
                        "class Student{  \n" +
                        "     int rollno;  \n" +
                        "     String name;  \n" +
                        "     String college=\"ITS\";  \n" +
                        "}  \n" +
                        "Suppose there are 500 students in my college, now all instance data members will get memory each time when the object is created. All students have its unique rollno and name, so instance data member is good in such case. Here, \"college\" refers to the common property of all objects. If we make it static, this field will get the memory only once.\n" +
                        "\n" +
                        "Java static property is shared to all objects.\n" +
                        "Example of static variable\n" +
                        "//Java Program to demonstrate the use of static variable  \n" +
                        "class Student{  \n" +
                        "   int rollno;//instance variable  \n" +
                        "   String name;  \n" +
                        "   static String college =\"ITS\";//static variable  \n" +
                        "   //constructor  \n" +
                        "   Student(int r, String n){  \n" +
                        "   rollno = r;  \n" +
                        "   name = n;  \n" +
                        "   }  \n" +
                        "   //method to display the values  \n" +
                        "   void display (){System.out.println(rollno+\" \"+name+\" \"+college);}  \n" +
                        "}  \n" +
                        "//Test class to show the values of objects  \n" +
                        "public class TestStaticVariable1{  \n" +
                        " public static void main(String args[]){  \n" +
                        " Student s1 = new Student(111,\"Karan\");  \n" +
                        " Student s2 = new Student(222,\"Aryan\");  \n" +
                        " //we can change the college of all objects by the single line of code  \n" +
                        " //Student.college=\"BBDIT\";  \n" +
                        " s1.display();  \n" +
                        " s2.display();  \n" +
                        " }  \n" +
                        "}  \n" +
                        "Output:\n" +
                        "\n" +
                        "111 Karan ITS\n" +
                        "222 Aryan ITS");
                put("5-6","Inheritance in Java is a mechanism in which one object acquires all the properties and behaviors of a parent object. It is an important part of OOPs (Object Oriented programming system).\n" +
                        "\n" +
                        "The idea behind inheritance in Java is that you can create new classes that are built upon existing classes. When you inherit from an existing class, you can reuse methods and fields of the parent class. Moreover, you can add new methods and fields in your current class also.\n" +
                        "\n" +
                        "Inheritance represents the IS-A relationship which is also known as a parent-child relationship.\n" +
                        "\n" +
                        "Why use inheritance in java\n" +
                        "For Method Overriding (so runtime polymorphism can be achieved).\n" +
                        "For Code Reusability.\n" +
                        "Terms used in Inheritance\n" +
                        "Class: A class is a group of objects which have common properties. It is a template or blueprint from which objects are created.\n" +
                        "Sub Class/Child Class: Subclass is a class which inherits the other class. It is also called a derived class, extended class, or child class.\n" +
                        "Super Class/Parent Class: Superclass is the class from where a subclass inherits the features. It is also called a base class or a parent class.\n" +
                        "Reusability: As the name specifies, reusability is a mechanism which facilitates you to reuse the fields and methods of the existing class when you create a new class. You can use the same fields and methods already defined in the previous class.\n" +
                        "The syntax of Java Inheritance\n" +
                        "class Subclass-name extends Superclass-name  \n" +
                        "{  \n" +
                        "   //methods and fields  \n" +
                        "}  \n" +
                        "The extends keyword indicates that you are making a new class that derives from an existing class. The meaning of \"extends\" is to increase the functionality.\n" +
                        "\n" +
                        "In the terminology of Java, a class which is inherited is called a parent or superclass, and the new class is called child or subclass." +
                        "");
                put("5-7", "Types of inheritance in java\n" +
                        "On the basis of class, there can be three types of inheritance in java: single, multilevel and hierarchical.\n" +
                        "\n" +
                        "In java programming, multiple and hybrid inheritance is supported through interface only. We will learn about interfaces later.\n" +
                        "\n" +
                        "Types of inheritance in Java\n" +
                        "Note: Multiple inheritance is not supported in Java through class.\n" +
                        "When one class inherits multiple classes, it is known as multiple inheritance. For Example:\n" +
                        "\n" +
                        "Multiple inheritance in Java\n" +
                        "Single Inheritance Example\n" +
                        "File: TestInheritance.java\n" +
                        "\n" +
                        "class Animal{  \n" +
                        "void eat(){System.out.println(\"eating...\");}  \n" +
                        "}  \n" +
                        "class Dog extends Animal{  \n" +
                        "void bark(){System.out.println(\"barking...\");}  \n" +
                        "}  \n" +
                        "class TestInheritance{  \n" +
                        "public static void main(String args[]){  \n" +
                        "Dog d=new Dog();  \n" +
                        "d.bark();  \n" +
                        "d.eat();  \n" +
                        "}}  \n" +
                        "Output:\n" +
                        "\n" +
                        "barking...\n" +
                        "eating...\n" +
                        "Multilevel Inheritance Example\n" +
                        "File: TestInheritance2.java\n" +
                        "\n" +
                        "class Animal{  \n" +
                        "void eat(){System.out.println(\"eating...\");}  \n" +
                        "}  \n" +
                        "class Dog extends Animal{  \n" +
                        "void bark(){System.out.println(\"barking...\");}  \n" +
                        "}  \n" +
                        "class BabyDog extends Dog{  \n" +
                        "void weep(){System.out.println(\"weeping...\");}  \n" +
                        "}  \n" +
                        "class TestInheritance2{  \n" +
                        "public static void main(String args[]){  \n" +
                        "BabyDog d=new BabyDog();  \n" +
                        "d.weep();  \n" +
                        "d.bark();  \n" +
                        "d.eat();  \n" +
                        "}}  \n" +
                        "Output:\n" +
                        "\n" +
                        "weeping...\n" +
                        "barking...\n" +
                        "eating...\n" +
                        "Hierarchical Inheritance Example\n" +
                        "File: TestInheritance3.java\n" +
                        "\n" +
                        "class Animal{  \n" +
                        "void eat(){System.out.println(\"eating...\");}  \n" +
                        "}  \n" +
                        "class Dog extends Animal{  \n" +
                        "void bark(){System.out.println(\"barking...\");}  \n" +
                        "}  \n" +
                        "class Cat extends Animal{  \n" +
                        "void meow(){System.out.println(\"meowing...\");}  \n" +
                        "}  \n" +
                        "class TestInheritance3{  \n" +
                        "public static void main(String args[]){  \n" +
                        "Cat c=new Cat();  \n" +
                        "c.meow();  \n" +
                        "c.eat();  \n" +
                        "//c.bark();//C.T.Error  \n" +
                        "}}  \n" +
                        "Output:\n" +
                        "\n" +
                        "meowing...\n" +
                        "eating...");
                put("5-8", "Final Keyword In Java" +
                        "The final keyword in java is used to restrict the user. The java final keyword can be used in many context. Final can be:\n" +
                        "\n" +
                        "variable\n" +
                        "method\n" +
                        "class\n" +
                        "The final keyword can be applied with the variables, a final variable that have no value it is called blank final variable or uninitialized final variable. It can be initialized in the constructor only. The blank final variable can be static also which will be initialized in the static block only. We will have detailed learning of these. Let's first learn the basics of final keyword.\n" +
                        "\n" +
                        "final keyword in java\n" +
                        "1) Java final variable\n" +
                        "If you make any variable as final, you cannot change the value of final variable(It will be constant).\n" +
                        "\n" +
                        "Example of final variable\n" +
                        "There is a final variable speedlimit, we are going to change the value of this variable, but It can't be changed because final variable once assigned a value can never be changed.\n" +
                        "\n" +
                        "class Bike9{  \n" +
                        " final int speedlimit=90;//final variable  \n" +
                        " void run(){  \n" +
                        "  speedlimit=400;  \n" +
                        " }  \n" +
                        " public static void main(String args[]){  \n" +
                        " Bike9 obj=new  Bike9();  \n" +
                        " obj.run();  \n" +
                        " }  \n" +
                        "}//end of class  \n" +
                        "Test it Now\n" +
                        "Output:Compile Time Error\n" +
                        "\n" +
                        " \n" +
                        "2) Java final method\n" +
                        "If you make any method as final, you cannot override it.\n" +
                        "\n" +
                        "Example of final method\n" +
                        "class Bike{  \n" +
                        "  final void run(){System.out.println(\"running\");}  \n" +
                        "}  \n" +
                        "     \n" +
                        "class Honda extends Bike{  \n" +
                        "   void run(){System.out.println(\"running safely with 100kmph\");}  \n" +
                        "     \n" +
                        "   public static void main(String args[]){  \n" +
                        "   Honda honda= new Honda();  \n" +
                        "   honda.run();  \n" +
                        "   }  \n" +
                        "}  \n" +
                        "Test it Now\n" +
                        "Output:Compile Time Error\n" +
                        "3) Java final class\n" +
                        "If you make any class as final, you cannot extend it.\n" +
                        "\n" +
                        "Example of final class\n" +
                        "final class Bike{}  \n" +
                        "  \n" +
                        "class Honda1 extends Bike{  \n" +
                        "  void run(){System.out.println(\"running safely with 100kmph\");}  \n" +
                        "    \n" +
                        "  public static void main(String args[]){  \n" +
                        "  Honda1 honda= new Honda1();  \n" +
                        "  honda.run();  \n" +
                        "  }  \n" +
                        "}  \n" +
                        "Test it Now\n" +
                        "Output:Compile Time Error");
                put("5-9", "As per dictionary, abstraction is the quality of dealing with ideas rather than events. For example, when you consider the case of e-mail, complex details such as what happens as soon as you send an e-mail, the protocol your e-mail server uses are hidden from the user. Therefore, to send an e-mail you just need to type the content, mention the address of the receiver, and click send.\n" +
                        "\n" +
                        "Likewise in Object-oriented programming, abstraction is a process of hiding the implementation details from the user, only the functionality will be provided to the user. In other words, the user will have the information on what the object does instead of how it does it.\n" +
                        "\n" +
                        "In Java, abstraction is achieved using Abstract classes and interfaces.\n" +
                        "\n" +
                        "Abstract Class\n" +
                        "A class which contains the abstract keyword in its declaration is known as abstract class.\n" +
                        "\n" +
                        "Abstract classes may or may not contain abstract methods, i.e., methods without body ( public void get(); )\n" +
                        "\n" +
                        "But, if a class has at least one abstract method, then the class must be declared abstract.\n" +
                        "\n" +
                        "If a class is declared abstract, it cannot be instantiated.\n" +
                        "\n" +
                        "To use an abstract class, you have to inherit it from another class, provide implementations to the abstract methods in it.\n" +
                        "\n" +
                        "If you inherit an abstract class, you have to provide implementations to all the abstract methods in it.\n" +
                        "\n" +
                        "Example\n" +
                        "This section provides you an example of the abstract class. To create an abstract class, just use the abstract keyword before the class keyword, in the class declaration.\n" +
                        "\n" +
                        "/* File name : Employee.java */\n" +
                        "public abstract class Employee {\n" +
                        "   private String name;\n" +
                        "   private String address;\n" +
                        "   private int number;\n" +
                        "\n" +
                        "   public Employee(String name, String address, int number) {\n" +
                        "      System.out.println(\"Constructing an Employee\");\n" +
                        "      this.name = name;\n" +
                        "      this.address = address;\n" +
                        "      this.number = number;\n" +
                        "   }\n" +
                        "   \n" +
                        "   public double computePay() {\n" +
                        "     System.out.println(\"Inside Employee computePay\");\n" +
                        "     return 0.0;\n" +
                        "   }\n" +
                        "   \n" +
                        "   public void mailCheck() {\n" +
                        "      System.out.println(\"Mailing a check to \" + this.name + \" \" + this.address);\n" +
                        "   }\n" +
                        "\n" +
                        "   public String toString() {\n" +
                        "      return name + \" \" + address + \" \" + number;\n" +
                        "   }\n" +
                        "\n" +
                        "   public String getName() {\n" +
                        "      return name;\n" +
                        "   }\n" +
                        " \n" +
                        "   public String getAddress() {\n" +
                        "      return address;\n" +
                        "   }\n" +
                        "   \n" +
                        "   public void setAddress(String newAddress) {\n" +
                        "      address = newAddress;\n" +
                        "   }\n" +
                        " \n" +
                        "   public int getNumber() {\n" +
                        "      return number;\n" +
                        "   }\n" +
                        "}\n" +
                        "You can observe that except abstract methods the Employee class is same as normal class in Java. The class is now abstract, but it still has three fields, seven methods, and one constructor.\n" +
                        "\n" +
                        "Now you can try to instantiate the Employee class in the following way −\n" +
                        "\n" +
                        "/* File name : AbstractDemo.java */\n" +
                        "public class AbstractDemo {\n" +
                        "\n" +
                        "   public static void main(String [] args) {\n" +
                        "      /* Following is not allowed and would raise error */\n" +
                        "      Employee e = new Employee(\"George W.\", \"Houston, TX\", 43);\n" +
                        "      System.out.println(\"\\n Call mailCheck using Employee reference--\");\n" +
                        "      e.mailCheck();\n" +
                        "   }\n" +
                        "}\n" +
                        "When you compile the above class, it gives you the following error −\n" +
                        "\n" +
                        "Employee.java:46: Employee is abstract; cannot be instantiated\n" +
                        "      Employee e = new Employee(\"George W.\", \"Houston, TX\", 43);\n" +
                        "                   ^\n" +
                        "1 error\n" +
                        "Inheriting the Abstract Class\n" +
                        "We can inherit the properties of Employee class just like concrete class in the following way −\n" +
                        "\n" +
                        "Example\n" +
                        "/* File name : Salary.java */\n" +
                        "public class Salary extends Employee {\n" +
                        "   private double salary;   // Annual salary\n" +
                        "   \n" +
                        "   public Salary(String name, String address, int number, double salary) {\n" +
                        "      super(name, address, number);\n" +
                        "      setSalary(salary);\n" +
                        "   }\n" +
                        "   \n" +
                        "   public void mailCheck() {\n" +
                        "      System.out.println(\"Within mailCheck of Salary class \");\n" +
                        "      System.out.println(\"Mailing check to \" + getName() + \" with salary \" + salary);\n" +
                        "   }\n" +
                        " \n" +
                        "   public double getSalary() {\n" +
                        "      return salary;\n" +
                        "   }\n" +
                        "   \n" +
                        "   public void setSalary(double newSalary) {\n" +
                        "      if(newSalary >= 0.0) {\n" +
                        "         salary = newSalary;\n" +
                        "      }\n" +
                        "   }\n" +
                        "   \n" +
                        "   public double computePay() {\n" +
                        "      System.out.println(\"Computing salary pay for \" + getName());\n" +
                        "      return salary/52;\n" +
                        "   }\n" +
                        "}\n" +
                        "Here, you cannot instantiate the Employee class, but you can instantiate the Salary Class, and using this instance you can access all the three fields and seven methods of Employee class as shown below.\n" +
                        "\n" +
                        "/* File name : AbstractDemo.java */\n" +
                        "public class AbstractDemo {\n" +
                        "\n" +
                        "   public static void main(String [] args) {\n" +
                        "      Salary s = new Salary(\"Mohd Mohtashim\", \"Ambehta, UP\", 3, 3600.00);\n" +
                        "      Employee e = new Salary(\"John Adams\", \"Boston, MA\", 2, 2400.00);\n" +
                        "      System.out.println(\"Call mailCheck using Salary reference --\");\n" +
                        "      s.mailCheck();\n" +
                        "      System.out.println(\"\\n Call mailCheck using Employee reference--\");\n" +
                        "      e.mailCheck();\n" +
                        "   }\n" +
                        "}\n" +
                        "This produces the following result −\n" +
                        "\n" +
                        "Output\n" +
                        "Constructing an Employee\n" +
                        "Constructing an Employee\n" +
                        "Call mailCheck using Salary reference --\n" +
                        "Within mailCheck of Salary class \n" +
                        "Mailing check to Mohd Mohtashim with salary 3600.0\n" +
                        "\n" +
                        " Call mailCheck using Employee reference--\n" +
                        "Within mailCheck of Salary class \n" +
                        "Mailing check to John Adams with salary 2400.0\n" +
                        "Abstract Methods\n" +
                        "If you want a class to contain a particular method but you want the actual implementation of that method to be determined by child classes, you can declare the method in the parent class as an abstract.\n" +
                        "\n" +
                        "abstract keyword is used to declare the method as abstract.\n" +
                        "\n" +
                        "You have to place the abstract keyword before the method name in the method declaration.\n" +
                        "\n" +
                        "An abstract method contains a method signature, but no method body.\n" +
                        "\n" +
                        "Instead of curly braces, an abstract method will have a semoi colon (;) at the end.\n" +
                        "\n" +
                        "Following is an example of the abstract method.\n" +
                        "\n" +
                        "Example\n" +
                        "public abstract class Employee {\n" +
                        "   private String name;\n" +
                        "   private String address;\n" +
                        "   private int number;\n" +
                        "   \n" +
                        "   public abstract double computePay();\n" +
                        "   // Remainder of class definition\n" +
                        "}\n" +
                        "Declaring a method as abstract has two consequences −\n" +
                        "\n" +
                        "The class containing it must be declared as abstract.\n" +
                        "\n" +
                        "Any class inheriting the current class must either override the abstract method or declare itself as abstract.\n" +
                        "\n" +
                        "Note − Eventually, a descendant class has to implement the abstract method; otherwise, you would have a hierarchy of abstract classes that cannot be instantiated.\n" +
                        "\n" +
                        "Suppose Salary class inherits the Employee class, then it should implement the computePay() method as shown below −\n" +
                        "\n" +
                        "/* File name : Salary.java */\n" +
                        "public class Salary extends Employee {\n" +
                        "   private double salary;   // Annual salary\n" +
                        "  \n" +
                        "   public double computePay() {\n" +
                        "      System.out.println(\"Computing salary pay for \" + getName());\n" +
                        "      return salary/52;\n" +
                        "   }\n" +
                        "   // Remainder of class definition\n" +
                        "}");
                ////////////////////////////////////////////////////////////////////////////////////////////
                put("6-0", "Normally, an array is a collection of similar type of elements that have a contiguous memory location.\n" +
                        "\n" +
                        "Java array is an object which contains elements of a similar data type. It is a data structure where we store similar elements. We can store only a fixed set of elements in a Java array.\n" +
                        "\n" +
                        "Array in java is index-based, the first element of the array is stored at the 0 index.\n" +
                        "\n" +
                        "java array\n" +
                        "Advantages\n" +
                        "Code Optimization: It makes the code optimized, we can retrieve or sort the data efficiently.\n" +
                        "Random access: We can get any data located at an index position.\n" +
                        "Disadvantages\n" +
                        "Size Limit: We can store only the fixed size of elements in the array. It doesn't grow its size at runtime. To solve this problem, collection framework is used in Java which grows automatically.\n" +
                        "\n" +
                        " \n" +
                        "Types of Array in java\n" +
                        "There are two types of array.\n" +
                        "\n" +
                        "Single Dimensional Array\n" +
                        "Multidimensional Array\n" +
                        "Single Dimensional Array in Java\n" +
                        "Syntax to Declare an Array in Java\n" +
                        "\n" +
                        "dataType[] arr; (or)  \n" +
                        "dataType []arr; (or)  \n" +
                        "dataType arr[];  \n" +
                        "Instantiation of an Array in Java\n" +
                        "\n" +
                        "arrayRefVar=new datatype[size];  \n" +
                        "Example of Java Array\n" +
                        "Let's see the simple example of java array, where we are going to declare, instantiate, initialize and traverse an array.\n" +
                        "\n" +
                        "//Java Program to illustrate how to declare, instantiate, initialize  \n" +
                        "//and traverse the Java array.  \n" +
                        "class Testarray{  \n" +
                        "public static void main(String args[]){  \n" +
                        "int a[]=new int[5];//declaration and instantiation  \n" +
                        "a[0]=10;//initialization  \n" +
                        "a[1]=20;  \n" +
                        "a[2]=70;  \n" +
                        "a[3]=40;  \n" +
                        "a[4]=50;  \n" +
                        "//traversing array  \n" +
                        "for(int i=0;i<a.length;i++)//length is the property of array  \n" +
                        "System.out.println(a[i]);  \n" +
                        "}}  \n" +
                        "Test it Now\n" +
                        "Output:\n" +
                        "\n" +
                        "10\n" +
                        "20\n" +
                        "70\n" +
                        "40\n" +
                        "50\n" +
                        "Declaration, Instantiation and Initialization of Java Array\n" +
                        "We can declare, instantiate and initialize the java array together by:\n" +
                        "\n" +
                        "int a[]={33,3,4,5};//declaration, instantiation and initialization  \n" +
                        "Let's see the simple example to print this array.\n" +
                        "\n" +
                        "//Java Program to illustrate the use of declaration, instantiation   \n" +
                        "//and initialization of Java array in a single line  \n" +
                        "class Testarray1{  \n" +
                        "public static void main(String args[]){  \n" +
                        "int a[]={33,3,4,5};//declaration, instantiation and initialization  \n" +
                        "//printing array  \n" +
                        "for(int i=0;i<a.length;i++)//length is the property of array  \n" +
                        "System.out.println(a[i]);  \n" +
                        "}}  \n" +
                        "Test it Now\n" +
                        "Output:\n" +
                        "\n" +
                        "33\n" +
                        "3\n" +
                        "4\n" +
                        "5\n" +
                        "Passing Array to Method in Java\n" +
                        "We can pass the java array to method so that we can reuse the same logic on any array.\n" +
                        "\n" +
                        "Let's see the simple example to get the minimum number of an array using a method.\n" +
                        "\n" +
                        "//Java Program to demonstrate the way of passing an array  \n" +
                        "//to method.  \n" +
                        "class Testarray2{  \n" +
                        "//creating a method which receives an array as a parameter  \n" +
                        "static void min(int arr[]){  \n" +
                        "int min=arr[0];  \n" +
                        "for(int i=1;i<arr.length;i++)  \n" +
                        " if(min>arr[i])  \n" +
                        "  min=arr[i];  \n" +
                        "  \n" +
                        "System.out.println(min);  \n" +
                        "}  \n" +
                        "  \n" +
                        "public static void main(String args[]){  \n" +
                        "int a[]={33,3,4,5};//declaring and initializing an array  \n" +
                        "min(a);//passing array to method  \n" +
                        "}}  \n" +
                        "Test it Now\n" +
                        "Output:\n" +
                        "\n" +
                        "3");
                put("6-1","Java String\n" +
                        "In Java, string is basically an object that represents sequence of char values. An array of characters works same as Java string. For example:\n" +
                        "\n" +
                        "char[] ch={'j','a','v','a','t','p','o','i','n','t'};  \n" +
                        "String s=new String(ch);  \n" +
                        "is same as:\n" +
                        "\n" +
                        "String s=\"javatpoint\";  \n" +
                        "Java String class provides a lot of methods to perform operations on string such as compare(), concat(), equals(), split(), length(), replace(), compareTo(), intern(), substring() etc.\n" +
                        "\n" +
                        "The java.lang.String class implements Serializable, Comparable and CharSequence interfaces.\n" +
                        "\n" +
                        "String in Java\n" +
                        "CharSequence Interface\n" +
                        "The CharSequence interface is used to represent the sequence of characters. String, StringBuffer and StringBuilder classes implement it. It means, we can create strings in java by using these three classes.\n" +
                        "\n" +
                        "CharSequence in Java\n" +
                        "The Java String is immutable which means it cannot be changed. Whenever we change any string, a new instance is created. For mutable strings, you can use StringBuffer and StringBuilder classes.\n" +
                        "\n" +
                        "We will discuss immutable string later. Let's first understand what is String in Java and how to create the String object.\n" +
                        "\n" +
                        "\n" +
                        " \n" +
                        "What is String in java\n" +
                        "Generally, String is a sequence of characters. But in Java, string is an object that represents a sequence of characters. The java.lang.String class is used to create a string object.\n" +
                        "\n" +
                        "How to create a string object?\n" +
                        "There are two ways to create String object:\n" +
                        "\n" +
                        "By string literal\n" +
                        "By new keyword\n" +
                        "1) String Literal\n" +
                        "Java String literal is created by using double quotes. For Example:\n" +
                        "\n" +
                        "String s=\"welcome\";  \n" +
                        "Each time you create a string literal, the JVM checks the \"string constant pool\" first. If the string already exists in the pool, a reference to the pooled instance is returned. If the string doesn't exist in the pool, a new string instance is created and placed in the pool. For example:\n" +
                        "\n" +
                        "String s1=\"Welcome\";  \n" +
                        "String s2=\"Welcome\";//It doesn't create a new instance  \n" +
                        "Java string literal\n" +
                        "In the above example, only one object will be created. Firstly, JVM will not find any string object with the value \"Welcome\" in string constant pool, that is why it will create a new object. After that it will find the string with the value \"Welcome\" in the pool, it will not create a new object but will return the reference to the same instance.");
                put("6-2", "Vector implements a dynamic array. It is similar to ArrayList, but with two differences −\n" +
                        "\n" +
                        "Vector is synchronized.\n" +
                        "\n" +
                        "Vector contains many legacy methods that are not part of the collections framework.\n" +
                        "\n" +
                        "Vector proves to be very useful if you don't know the size of the array in advance or you just need one that can change sizes over the lifetime of a program.\n" +
                        "\n" +
                        "Following is the list of constructors provided by the vector class.\n" +
                        "\n" +
                        "Sr.No.\tConstructor & Description\n" +
                        "1\t\n" +
                        "Vector( )\n" +
                        "\n" +
                        "This constructor creates a default vector, which has an initial size of 10.\n" +
                        "\n" +
                        "2\t\n" +
                        "Vector(int size)\n" +
                        "\n" +
                        "This constructor accepts an argument that equals to the required size, and creates a vector whose initial capacity is specified by size.\n" +
                        "\n" +
                        "3\t\n" +
                        "Vector(int size, int incr)\n" +
                        "\n" +
                        "This constructor creates a vector whose initial capacity is specified by size and whose increment is specified by incr. The increment specifies the number of elements to allocate each time that a vector is resized upward.\n" +
                        "\n" +
                        "4\t\n" +
                        "Vector(Collection c)\n" +
                        "\n" +
                        "This constructor creates a vector that contains the elements of collection c.\n" +
                        "\n" +
                        "Apart from the methods inherited from its parent classes, Vector defines the following methods −\n" +
                        "\n" +
                        "Sr.No.\tMethod & Description\n" +
                        "1\t\n" +
                        "void add(int index, Object element)\n" +
                        "\n" +
                        "Inserts the specified element at the specified position in this Vector.\n" +
                        "\n" +
                        "2\t\n" +
                        "boolean add(Object o)\n" +
                        "\n" +
                        "Appends the specified element to the end of this Vector.\n" +
                        "\n" +
                        "3\t\n" +
                        "boolean addAll(Collection c)\n" +
                        "\n" +
                        "Appends all of the elements in the specified Collection to the end of this Vector, in the order that they are returned by the specified Collection's Iterator.\n" +
                        "\n" +
                        "4\t\n" +
                        "boolean addAll(int index, Collection c)\n" +
                        "\n" +
                        "Inserts all of the elements in in the specified Collection into this Vector at the specified position.\n" +
                        "\n" +
                        "5\t\n" +
                        "void addElement(Object obj)\n" +
                        "\n" +
                        "Adds the specified component to the end of this vector, increasing its size by one.\n" +
                        "\n" +
                        "6\t\n" +
                        "int capacity()\n" +
                        "\n" +
                        "Returns the current capacity of this vector.\n" +
                        "\n" +
                        "7\t\n" +
                        "void clear()\n" +
                        "\n" +
                        "Removes all of the elements from this vector.\n" +
                        "\n" +
                        "8\t\n" +
                        "Object clone()\n" +
                        "\n" +
                        "Returns a clone of this vector.\n" +
                        "\n" +
                        "9\t\n" +
                        "boolean contains(Object elem)\n" +
                        "\n" +
                        "Tests if the specified object is a component in this vector.\n" +
                        "\n" +
                        "10\t\n" +
                        "boolean containsAll(Collection c)\n" +
                        "\n" +
                        "Returns true if this vector contains all of the elements in the specified Collection.\n" +
                        "\n" +
                        "11\t\n" +
                        "void copyInto(Object[] anArray)\n" +
                        "\n" +
                        "Copies the components of this vector into the specified array.\n" +
                        "\n" +
                        "12\t\n" +
                        "Object elementAt(int index)\n" +
                        "\n" +
                        "Returns the component at the specified index.\n" +
                        "\n" +
                        "13\t\n" +
                        "Enumeration elements()\n" +
                        "\n" +
                        "Returns an enumeration of the components of this vector.\n" +
                        "\n" +
                        "14\t\n" +
                        "void ensureCapacity(int minCapacity)\n" +
                        "\n" +
                        "Increases the capacity of this vector, if necessary, to ensure that it can hold at least the number of components specified by the minimum capacity argument.\n" +
                        "\n" +
                        "15\t\n" +
                        "boolean equals(Object o)\n" +
                        "\n" +
                        "Compares the specified Object with this vector for equality.\n" +
                        "\n" +
                        "16\t\n" +
                        "Object firstElement()\n" +
                        "\n" +
                        "Returns the first component (the item at index 0) of this vector.\n" +
                        "\n" +
                        "17\t\n" +
                        "Object get(int index)\n" +
                        "\n" +
                        "Returns the element at the specified position in this vector.\n" +
                        "\n" +
                        "18\t\n" +
                        "int hashCode()\n" +
                        "\n" +
                        "Returns the hash code value for this vector.\n" +
                        "\n" +
                        "19\t\n" +
                        "int indexOf(Object elem)\n" +
                        "\n" +
                        "Searches for the first occurence of the given argument, testing for equality using the equals method.\n" +
                        "\n" +
                        "20\t\n" +
                        "int indexOf(Object elem, int index)\n" +
                        "\n" +
                        "Searches for the first occurence of the given argument, beginning the search at index, and testing for equality using the equals method.\n" +
                        "\n" +
                        "21\t\n" +
                        "void insertElementAt(Object obj, int index)\n" +
                        "\n" +
                        "Inserts the specified object as a component in this vector at the specified index.\n" +
                        "\n" +
                        "22\t\n" +
                        "boolean isEmpty()\n" +
                        "\n" +
                        "Tests if this vector has no components.\n" +
                        "\n" +
                        "23\t\n" +
                        "Object lastElement()\n" +
                        "\n" +
                        "Returns the last component of the vector.\n" +
                        "\n" +
                        "24\t\n" +
                        "int lastIndexOf(Object elem)\n" +
                        "\n" +
                        "Returns the index of the last occurrence of the specified object in this vector.\n" +
                        "\n" +
                        "25\t\n" +
                        "int lastIndexOf(Object elem, int index)\n" +
                        "\n" +
                        "Searches backwards for the specified object, starting from the specified index, and returns an index to it.\n" +
                        "\n" +
                        "26\t\n" +
                        "Object remove(int index)\n" +
                        "\n" +
                        "Removes the element at the specified position in this vector.\n" +
                        "\n" +
                        "27\t\n" +
                        "boolean remove(Object o)\n" +
                        "\n" +
                        "Removes the first occurrence of the specified element in this vector, If the vector does not contain the element, it is unchanged.\n" +
                        "\n" +
                        "28\t\n" +
                        "boolean removeAll(Collection c)\n" +
                        "\n" +
                        "Removes from this vector all of its elements that are contained in the specified Collection.\n" +
                        "\n" +
                        "29\t\n" +
                        "void removeAllElements()\n" +
                        "\n" +
                        "Removes all components from this vector and sets its size to zero.\n" +
                        "\n" +
                        "30\t\n" +
                        "boolean removeElement(Object obj)\n" +
                        "\n" +
                        "Removes the first (lowest-indexed) occurrence of the argument from this vector.\n" +
                        "\n" +
                        "31\t\n" +
                        "void removeElementAt(int index)\n" +
                        "\n" +
                        "removeElementAt(int index).\n" +
                        "\n" +
                        "32\t\n" +
                        "protected void removeRange(int fromIndex, int toIndex)\n" +
                        "\n" +
                        "Removes from this List all of the elements whose index is between fromIndex, inclusive and toIndex, exclusive.\n" +
                        "\n" +
                        "33\t\n" +
                        "boolean retainAll(Collection c)\n" +
                        "\n" +
                        "Retains only the elements in this vector that are contained in the specified Collection.\n" +
                        "\n" +
                        "34\t\n" +
                        "Object set(int index, Object element)\n" +
                        "\n" +
                        "Replaces the element at the specified position in this vector with the specified element.\n" +
                        "\n" +
                        "35\t\n" +
                        "void setElementAt(Object obj, int index)\n" +
                        "\n" +
                        "Sets the component at the specified index of this vector to be the specified object.\n" +
                        "\n" +
                        "36\t\n" +
                        "void setSize(int newSize)\n" +
                        "\n" +
                        "Sets the size of this vector.\n" +
                        "\n" +
                        "37\t\n" +
                        "int size()\n" +
                        "\n" +
                        "Returns the number of components in this vector.\n" +
                        "\n" +
                        "38\t\n" +
                        "List subList(int fromIndex, int toIndex)\n" +
                        "\n" +
                        "Returns a view of the portion of this List between fromIndex, inclusive, and toIndex, exclusive.\n" +
                        "\n" +
                        "39\t\n" +
                        "Object[] toArray()\n" +
                        "\n" +
                        "Returns an array containing all of the elements in this vector in the correct order.\n" +
                        "\n" +
                        "40\t\n" +
                        "Object[] toArray(Object[] a)\n" +
                        "\n" +
                        "Returns an array containing all of the elements in this vector in the correct order; the runtime type of the returned array is that of the specified array.\n" +
                        "\n" +
                        "41\t\n" +
                        "String toString()\n" +
                        "\n" +
                        "Returns a string representation of this vector, containing the String representation of each element.\n" +
                        "\n" +
                        "42\t\n" +
                        "void trimToSize()\n" +
                        "\n" +
                        "Trims the capacity of this vector to be the vector's current size.\n" +
                        "\n" +
                        "Example\n" +
                        "The following program illustrates several of the methods supported by this collection −\n" +
                        "\n" +
                        " Live Demo\n" +
                        "import java.util.*;\n" +
                        "public class VectorDemo {\n" +
                        "\n" +
                        "   public static void main(String args[]) {\n" +
                        "      // initial size is 3, increment is 2\n" +
                        "      Vector v = new Vector(3, 2);\n" +
                        "      System.out.println(\"Initial size: \" + v.size());\n" +
                        "      System.out.println(\"Initial capacity: \" + v.capacity());\n" +
                        "      \n" +
                        "      v.addElement(new Integer(1));\n" +
                        "      v.addElement(new Integer(2));\n" +
                        "      v.addElement(new Integer(3));\n" +
                        "      v.addElement(new Integer(4));\n" +
                        "      System.out.println(\"Capacity after four additions: \" + v.capacity());\n" +
                        "\n" +
                        "      v.addElement(new Double(5.45));\n" +
                        "      System.out.println(\"Current capacity: \" + v.capacity());\n" +
                        "      \n" +
                        "      v.addElement(new Double(6.08));\n" +
                        "      v.addElement(new Integer(7));\n" +
                        "      System.out.println(\"Current capacity: \" + v.capacity());\n" +
                        "      \n" +
                        "      v.addElement(new Float(9.4));\n" +
                        "      v.addElement(new Integer(10));\n" +
                        "      System.out.println(\"Current capacity: \" + v.capacity());\n" +
                        "      \n" +
                        "      v.addElement(new Integer(11));\n" +
                        "      v.addElement(new Integer(12));\n" +
                        "      System.out.println(\"First element: \" + (Integer)v.firstElement());\n" +
                        "      System.out.println(\"Last element: \" + (Integer)v.lastElement());\n" +
                        "      \n" +
                        "      if(v.contains(new Integer(3)))\n" +
                        "         System.out.println(\"Vector contains 3.\");\n" +
                        "         \n" +
                        "      // enumerate the elements in the vector.\n" +
                        "      Enumeration vEnum = v.elements();\n" +
                        "      System.out.println(\"\\nElements in vector:\");\n" +
                        "      \n" +
                        "      while(vEnum.hasMoreElements())\n" +
                        "         System.out.print(vEnum.nextElement() + \" \");\n" +
                        "      System.out.println();\n" +
                        "   }\n" +
                        "}\n" +
                        "This will produce the following result −\n" +
                        "\n" +
                        "Output\n" +
                        "Initial size: 0\n" +
                        "Initial capacity: 3\n" +
                        "Capacity after four additions: 5\n" +
                        "Current capacity: 5\n" +
                        "Current capacity: 7\n" +
                        "Current capacity: 9\n" +
                        "First element: 1\n" +
                        "Last element: 12\n" +
                        "Vector contains 3.\n" +
                        "\n" +
                        "Elements in vector:\n" +
                        "1 2 3 4 5.45 6.08 7 9.4 10 11 12\n" +
                        "\n" +
                        " \n" +
                        "\n" +
                        " \n");
                put("6-3", "Wrapper class in java provides the mechanism to convert primitive into object and object into primitive.\n" +
                        "\n" +
                        "Since J2SE 5.0, autoboxing and unboxing feature converts primitive into object and object into primitive automatically. The automatic conversion of primitive into object is known as autoboxing and vice-versa unboxing.\n" +
                        "\n" +
                        "The eight classes of java.lang package are known as wrapper classes in java. The list of eight wrapper classes are given below:\n" +
                        "\n" +
                        "Primitive Type\tWrapper class\n" +
                        "boolean\tBoolean\n" +
                        "char\tCharacter\n" +
                        "byte\tByte\n" +
                        "short\tShort\n" +
                        "int\tInteger\n" +
                        "long\tLong\n" +
                        "float\tFloat\n" +
                        "double\tDouble\n" +
                        "\n" +
                        " \n" +
                        "Wrapper class Example: Primitive to Wrapper\n" +
                        "public class WrapperExample1{  \n" +
                        "public static void main(String args[]){  \n" +
                        "//Converting int into Integer  \n" +
                        "int a=20;  \n" +
                        "Integer i=Integer.valueOf(a);//converting int into Integer  \n" +
                        "Integer j=a;//autoboxing, now compiler will write Integer.valueOf(a) internally  \n" +
                        "  \n" +
                        "System.out.println(a+\" \"+i+\" \"+j);  \n" +
                        "}}  \n" +
                        "Output:\n" +
                        "\n" +
                        "20 20 20\n" +
                        "Wrapper class Example: Wrapper to Primitive\n" +
                        "public class WrapperExample2{    \n" +
                        "public static void main(String args[]){    \n" +
                        "//Converting Integer to int    \n" +
                        "Integer a=new Integer(3);    \n" +
                        "int i=a.intValue();//converting Integer to int  \n" +
                        "int j=a;//unboxing, now compiler will write a.intValue() internally    \n" +
                        "    \n" +
                        "System.out.println(a+\" \"+i+\" \"+j);    \n" +
                        "}}    \n" +
                        "Output:\n" +
                        "\n" +
                        "3 3 3");
                ///////////////////////////////////////////////////////////////////////////////////////////////////////
                put("7-0", "An interface is a reference type in Java. It is similar to class. It is a collection of abstract methods. A class implements an interface, thereby inheriting the abstract methods of the interface.\n" +
                        "\n" +
                        "Along with abstract methods, an interface may also contain constants, default methods, static methods, and nested types. Method bodies exist only for default methods and static methods.\n" +
                        "\n" +
                        "Writing an interface is similar to writing a class. But a class describes the attributes and behaviors of an object. And an interface contains behaviors that a class implements.\n" +
                        "\n" +
                        "Unless the class that implements the interface is abstract, all the methods of the interface need to be defined in the class.\n" +
                        "\n" +
                        "An interface is similar to a class in the following ways −\n" +
                        "\n" +
                        "An interface can contain any number of methods.\n" +
                        "\n" +
                        "An interface is written in a file with a .java extension, with the name of the interface matching the name of the file.\n" +
                        "\n" +
                        "The byte code of an interface appears in a .class file.\n" +
                        "\n" +
                        "Interfaces appear in packages, and their corresponding bytecode file must be in a directory structure that matches the package name.\n" +
                        "\n" +
                        "However, an interface is different from a class in several ways, including −\n" +
                        "\n" +
                        "You cannot instantiate an interface.\n" +
                        "\n" +
                        "An interface does not contain any constructors.\n" +
                        "\n" +
                        "All of the methods in an interface are abstract.\n" +
                        "\n" +
                        "An interface cannot contain instance fields. The only fields that can appear in an interface must be declared both static and final.\n" +
                        "\n" +
                        "An interface is not extended by a class; it is implemented by a class.\n" +
                        "\n" +
                        "An interface can extend multiple interfaces.\n" +
                        "\n" +
                        "Declaring Interfaces\n" +
                        "The interface keyword is used to declare an interface. Here is a simple example to declare an interface −\n" +
                        "\n" +
                        "Example\n" +
                        "Following is an example of an interface −\n" +
                        "\n" +
                        "/* File name : NameOfInterface.java */\n" +
                        "import java.lang.*;\n" +
                        "// Any number of import statements\n" +
                        "\n" +
                        "public interface NameOfInterface {\n" +
                        "   // Any number of final, static fields\n" +
                        "   // Any number of abstract method declarations\\\n" +
                        "}\n" +
                        "Interfaces have the following properties −\n" +
                        "\n" +
                        "An interface is implicitly abstract. You do not need to use the abstract keyword while declaring an interface.\n" +
                        "\n" +
                        "Each method in an interface is also implicitly abstract, so the abstract keyword is not needed.\n" +
                        "\n" +
                        "Methods in an interface are implicitly public.\n" +
                        "\n" +
                        "Example\n" +
                        "/* File name : Animal.java */\n" +
                        "interface Animal {\n" +
                        "   public void eat();\n" +
                        "   public void travel();\n" +
                        "}");
                put("7-1", "Extending Interfaces\n" +
                        "An interface can extend another interface in the same way that a class can extend another class. The extends keyword is used to extend an interface, and the child interface inherits the methods of the parent interface.\n" +
                        "\n" +
                        "The following Sports interface is extended by Hockey and Football interfaces.\n" +
                        "\n" +
                        "Example\n" +
                        "// Filename: Sports.java\n" +
                        "public interface Sports {\n" +
                        "   public void setHomeTeam(String name);\n" +
                        "   public void setVisitingTeam(String name);\n" +
                        "}\n" +
                        "\n" +
                        "// Filename: Football.java\n" +
                        "public interface Football extends Sports {\n" +
                        "   public void homeTeamScored(int points);\n" +
                        "   public void visitingTeamScored(int points);\n" +
                        "   public void endOfQuarter(int quarter);\n" +
                        "}\n" +
                        "\n" +
                        "// Filename: Hockey.java\n" +
                        "public interface Hockey extends Sports {\n" +
                        "   public void homeGoalScored();\n" +
                        "   public void visitingGoalScored();\n" +
                        "   public void endOfPeriod(int period);\n" +
                        "   public void overtimePeriod(int ot);\n" +
                        "}\n" +
                        "The Hockey interface has four methods, but it inherits two from Sports; thus, a class that implements Hockey needs to implement all six methods. Similarly, a class that implements Football needs to define the three methods from Football and the two methods from Sports.");
                put("7-2", "Implementing Interfaces\n" +
                        "When a class implements an interface, you can think of the class as signing a contract, agreeing to perform the specific behaviors of the interface. If a class does not perform all the behaviors of the interface, the class must declare itself as abstract.\n" +
                        "\n" +
                        "A class uses the implements keyword to implement an interface. The implements keyword appears in the class declaration following the extends portion of the declaration.\n" +
                        "\n" +
                        "Example\n" +
                        "/* File name : MammalInt.java */\n" +
                        "public class MammalInt implements Animal {\n" +
                        "\n" +
                        "   public void eat() {\n" +
                        "      System.out.println(\"Mammal eats\");\n" +
                        "   }\n" +
                        "\n" +
                        "   public void travel() {\n" +
                        "      System.out.println(\"Mammal travels\");\n" +
                        "   } \n" +
                        "\n" +
                        "   public int noOfLegs() {\n" +
                        "      return 0;\n" +
                        "   }\n" +
                        "\n" +
                        "   public static void main(String args[]) {\n" +
                        "      MammalInt m = new MammalInt();\n" +
                        "      m.eat();\n" +
                        "      m.travel();\n" +
                        "   }\n" +
                        "} \n" +
                        "This will produce the following result −\n" +
                        "\n" +
                        "Output\n" +
                        "Mammal eats\n" +
                        "Mammal travels\n" +
                        "When overriding methods defined in interfaces, there are several rules to be followed −\n" +
                        "\n" +
                        "Checked exceptions should not be declared on implementation methods other than the ones declared by the interface method or subclasses of those declared by the interface method.\n" +
                        "\n" +
                        "The signature of the interface method and the same return type or subtype should be maintained when overriding the methods.\n" +
                        "\n" +
                        "An implementation class itself can be abstract and if so, interface methods need not be implemented.\n" +
                        "\n" +
                        "When implementation interfaces, there are several rules −\n" +
                        "\n" +
                        "A class can implement more than one interface at a time.\n" +
                        "\n" +
                        "A class can extend only one class, but implement many interfaces.\n" +
                        "\n" +
                        "An interface can extend another interface, in a similar way as a class can extend another class.");
                put("7-3", "The  variables of an interface are always declared as \"final\". Final variables are those variables, whose  values are constants and cannot be changed. The class that implements the interface can use the variables as declared in the interface and cannot modify or changed the value of the variable.\n" +
                        "\n" +
                        " \n" +
                        "\n" +
                        " interface selectcolor\n" +
                        "{\n" +
                        "int blue=4;\n" +
                        "int yellow=5;\n" +
                        "int pink=6;\n" +
                        "public void choose(int color);\n" +
                        "}\n" +
                        "class selectimp implements selectcolor\n" +
                        "{\n" +
                        "public void choose(int color)\n" +
                        "{\n" +
                        "switch(color)\n" +
                        "{\n" +
                        "case blue:\n" +
                        "   System.out.println(\"The color selected is blue\");\n" +
                        "   break;\n" +
                        "case yellow:\n" +
                        "   System.out.println(\"The color selected is yellow\");\n" +
                        "   break;\n" +
                        "case pink:\n" +
                        "   System.out.println(\"The color selected is pink\");\n" +
                        "   break;\n" +
                        "}\n" +
                        "}\n" +
                        "public static void main(String aa[])\n" +
                        "{\n" +
                        "int a1,b1,c1;\n" +
                        "a1=Integer.parseInt(aa[0]);\n" +
                        "b1=Integer.parseInt(aa[1]);\n" +
                        "c1=Integer.parseInt(aa[2]);\n" +
                        "\n" +
                        "\n" +
                        "selectimp st=new selectimp();\n" +
                        "st.choose(a1);\n" +
                        "st.choose(b1);\n" +
                        "st.choose(c1);\n" +
                        "}\n" +
                        "}\n" +
                        "\n" +
                        "accessible interface variables in java\n" +
                        "Explanation....\n" +
                        "In this example first  an interface selectcolor is created and the value for the integers blue, yellow, pink are set as 4,5,6.\n" +
                        "Then a method choose() which takes an integer parameter is declared.\n" +
                        "A class selectimp is created, which implements the interface selectcolor.\n" +
                        "Then the method choose() of the interface selectcolor is implemented using the switch case statements.\n" +
                        "Then there is a main() which creates the object of the class selectimp and call the choose() of the selectimp class with different parameters or arguments.");

///////////////////////////////////////////////////////////////////////////////////////////
                put("8-0","Java Package" +
                        "A java package is a group of similar types of classes, interfaces and sub-packages.\n" +
                        "\n" +
                        "Package in java can be categorized in two form, built-in package and user-defined package.\n" +
                        "\n" +
                        "There are many built-in packages such as java, lang, awt, javax, swing, net, io, util, sql etc.\n" +
                        "\n" +
                        "Here, we will have the detailed learning of creating and using user-defined packages.\n" +
                        "\n" +
                        "Advantage of Java Package\n" +
                        "1) Java package is used to categorize the classes and interfaces so that they can be easily maintained.\n" +
                        "\n" +
                        "2) Java package provides access protection.\n" +
                        "\n" +
                        "3) Java package removes naming collision.Simple example of java package\n" +
                        "The package keyword is used to create a package in java.\n" +
                        "\n" +
                        "//save as Simple.java  \n" +
                        "package mypack;  \n" +
                        "public class Simple{  \n" +
                        " public static void main(String args[]){  \n" +
                        "    System.out.println(\"Welcome to package\");  \n" +
                        "   }  \n" +
                        "}  \n" +
                        "How to compile java package\n" +
                        "If you are not using any IDE, you need to follow the syntax given below:\n" +
                        "\n" +
                        "javac -d directory javafilename  \n" +
                        "For example\n" +
                        "\n" +
                        "javac -d . Simple.java  \n" +
                        "The -d switch specifies the destination where to put the generated class file. You can use any directory name like /home (in case of Linux), d:/abc (in case of windows) etc. If you want to keep the package within the same directory, you can use . (dot).\n" +
                        "\n" +
                        "How to run java package program\n" +
                        "You need to use fully qualified name e.g. mypack.Simple etc to run the class.\n" +
                        "\n" +
                        "To Compile: javac -d . Simple.java\n" +
                        "To Run: java mypack.Simple\n" +
                        "Output:Welcome to package\n" +
                        "The -d is a switch that tells the compiler where to put the class file i.e. it represents destination. The . represents the current folder.");
                put("8-1","API Packages\n" +
                        "\n" +
                        "Java APl(Application Program Interface) provides a large numbers of classes grouped into different packages according to functionality. Most of the time we use the packages available with the the Java API. Following figure shows the system packages that are frequently used in the programs.\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        " \n" +
                        "\n" +
                        "Java System Packages and Their Classes\n" +
                        "java.lang\tLanguage support classes. They include classes for primitive types, string, math functions, thread and exceptions.\n" +
                        "java.util\tLanguage utility classes such as vectors, hash tables, random numbers, data, etc.\n" +
                        "java.io\tInput/output support classes. They provide facilities for the input and output of data.\n" +
                        "java.applet\tClasses for creating and implementing applets.\n" +
                        "java.net\tClasses for networking. They include classes for communicating with local computers as well as with internet servers.\n" +
                        "java.awt\tSet of classes for implementing graphical user interface. They include classes for windows, buttons, lists, menus and so on.\n" );
                put("8-2","The java.awt package is the main package of the AWT, or Abstract Windowing Toolkit. It contains classes for graphics, including the Java 2D graphics capabilities introduced in the Java 2 platform, and also defines the basic graphical user interface (GUI) framework for Java.");
                ///////////////////////////////////////////////////////////////////////////////
                put("9-0", "How to create thread\n" +
                        "There are two ways to create a thread:\n" +
                        "\n" +
                        "By extending Thread class\n" +
                        "By implementing Runnable interface.\n" +
                        "Thread class:\n" +
                        "Thread class provide constructors and methods to create and perform operations on a thread.Thread class extends Object class and implements Runnable interface.\n" +
                        "Commonly used Constructors of Thread class:\n" +
                        "Thread()\n" +
                        "Thread(String name)\n" +
                        "Thread(Runnable r)\n" +
                        "Thread(Runnable r,String name)\n" +
                        "Commonly used methods of Thread class:\n" +
                        "public void run(): is used to perform action for a thread.\n" +
                        "public void start(): starts the execution of the thread.JVM calls the run() method on the thread.\n" +
                        "public void sleep(long miliseconds): Causes the currently executing thread to sleep (temporarily cease execution) for the specified number of milliseconds.\n" +
                        "public void join(): waits for a thread to die.\n" +
                        "public void join(long miliseconds): waits for a thread to die for the specified miliseconds.\n" +
                        "public int getPriority(): returns the priority of the thread.\n" +
                        "public int setPriority(int priority): changes the priority of the thread.\n" +
                        "public String getName(): returns the name of the thread.\n" +
                        "public void setName(String name): changes the name of the thread.\n" +
                        "public Thread currentThread(): returns the reference of currently executing thread.\n" +
                        "public int getId(): returns the id of the thread.\n" +
                        "public Thread.State getState(): returns the state of the thread.\n" +
                        "public boolean isAlive(): tests if the thread is alive.\n" +
                        "public void yield(): causes the currently executing thread object to temporarily pause and allow other threads to execute.\n" +
                        "public void suspend(): is used to suspend the thread(depricated).\n" +
                        "public void resume(): is used to resume the suspended thread(depricated).\n" +
                        "public void stop(): is used to stop the thread(depricated).\n" +
                        "public boolean isDaemon(): tests if the thread is a daemon thread.\n" +
                        "public void setDaemon(boolean b): marks the thread as daemon or user thread.\n" +
                        "public void interrupt(): interrupts the thread.\n" +
                        "public boolean isInterrupted(): tests if the thread has been interrupted.\n" +
                        "public static boolean interrupted(): tests if the current thread has been interrupted.");
                put("9-1", "Core Java provides complete control over multithreaded program. You can develop a multithreaded program which can be suspended, resumed, or stopped completely based on your requirements. There are various static methods which you can use on thread objects to control their behavior. Following table lists down those methods −\n" +
                        "\n" +
                        "Sr.No.\tMethod & Description\n" +
                        "1\t\n" +
                        "public void suspend()\n" +
                        "\n" +
                        "This method puts a thread in the suspended state and can be resumed using resume() method.\n" +
                        "\n" +
                        "2\t\n" +
                        "public void stop()\n" +
                        "\n" +
                        "This method stops a thread completely.\n" +
                        "\n" +
                        "3\t\n" +
                        "public void resume()\n" +
                        "\n" +
                        "This method resumes a thread, which was suspended using suspend() method.\n" +
                        "\n" +
                        "4\t\n" +
                        "public void wait()\n" +
                        "\n" +
                        "Causes the current thread to wait until another thread invokes the notify().\n" +
                        "\n" +
                        "5\t\n" +
                        "public void notify()\n" +
                        "\n" +
                        "Wakes up a single thread that is waiting on this object's monitor.\n" +
                        "\n" +
                        "Be aware that the latest versions of Java has deprecated the usage of suspend( ), resume( ), and stop( ) methods and so you need to use available alternatives.\n" +
                        "\n" +
                        "Example\n" +
                        " Live Demo\n" +
                        "class RunnableDemo implements Runnable {\n" +
                        "   public Thread t;\n" +
                        "   private String threadName;\n" +
                        "   boolean suspended = false;\n" +
                        "\n" +
                        "   RunnableDemo( String name) {\n" +
                        "      threadName = name;\n" +
                        "      System.out.println(\"Creating \" +  threadName );\n" +
                        "   }\n" +
                        "   \n" +
                        "   public void run() {\n" +
                        "      System.out.println(\"Running \" +  threadName );\n" +
                        "      try {\n" +
                        "         for(int i = 10; i > 0; i--) {\n" +
                        "            System.out.println(\"Thread: \" + threadName + \", \" + i);\n" +
                        "            // Let the thread sleep for a while.\n" +
                        "            Thread.sleep(300);\n" +
                        "            synchronized(this) {\n" +
                        "               while(suspended) {\n" +
                        "                  wait();\n" +
                        "               }\n" +
                        "            }\n" +
                        "         }\n" +
                        "      } catch (InterruptedException e) {\n" +
                        "         System.out.println(\"Thread \" +  threadName + \" interrupted.\");\n" +
                        "      }\n" +
                        "      System.out.println(\"Thread \" +  threadName + \" exiting.\");\n" +
                        "   }\n" +
                        "\n" +
                        "   public void start () {\n" +
                        "      System.out.println(\"Starting \" +  threadName );\n" +
                        "      if (t == null) {\n" +
                        "         t = new Thread (this, threadName);\n" +
                        "         t.start ();\n" +
                        "      }\n" +
                        "   }\n" +
                        "   \n" +
                        "   void suspend() {\n" +
                        "      suspended = true;\n" +
                        "   }\n" +
                        "   \n" +
                        "   synchronized void resume() {\n" +
                        "      suspended = false;\n" +
                        "      notify();\n" +
                        "   }\n" +
                        "}\n" +
                        "\n" +
                        "public class TestThread {\n" +
                        "\n" +
                        "   public static void main(String args[]) {\n" +
                        "\n" +
                        "      RunnableDemo R1 = new RunnableDemo( \"Thread-1\");\n" +
                        "      R1.start();\n" +
                        "\n" +
                        "      RunnableDemo R2 = new RunnableDemo( \"Thread-2\");\n" +
                        "      R2.start();\n" +
                        "\n" +
                        "      try {\n" +
                        "         Thread.sleep(1000);\n" +
                        "         R1.suspend();\n" +
                        "         System.out.println(\"Suspending First Thread\");\n" +
                        "         Thread.sleep(1000);\n" +
                        "         R1.resume();\n" +
                        "         System.out.println(\"Resuming First Thread\");\n" +
                        "         \n" +
                        "         R2.suspend();\n" +
                        "         System.out.println(\"Suspending thread Two\");\n" +
                        "         Thread.sleep(1000);\n" +
                        "         R2.resume();\n" +
                        "         System.out.println(\"Resuming thread Two\");\n" +
                        "      } catch (InterruptedException e) {\n" +
                        "         System.out.println(\"Main thread Interrupted\");\n" +
                        "      }try {\n" +
                        "         System.out.println(\"Waiting for threads to finish.\");\n" +
                        "         R1.t.join();\n" +
                        "         R2.t.join();\n" +
                        "      } catch (InterruptedException e) {\n" +
                        "         System.out.println(\"Main thread Interrupted\");\n" +
                        "      }\n" +
                        "      System.out.println(\"Main thread exiting.\");\n" +
                        "   }\n" +
                        "}\n" +
                        "The above program produces the following output −\n" +
                        "\n" +
                        "Output\n" +
                        "Creating Thread-1\n" +
                        "Starting Thread-1\n" +
                        "Creating Thread-2\n" +
                        "Starting Thread-2\n" +
                        "Running Thread-1\n" +
                        "Thread: Thread-1, 10\n" +
                        "Running Thread-2\n" +
                        "Thread: Thread-2, 10\n" +
                        "Thread: Thread-1, 9\n" +
                        "Thread: Thread-2, 9\n" +
                        "Thread: Thread-1, 8\n" +
                        "Thread: Thread-2, 8\n" +
                        "Thread: Thread-1, 7\n" +
                        "Thread: Thread-2, 7\n" +
                        "Suspending First Thread\n" +
                        "Thread: Thread-2, 6\n" +
                        "Thread: Thread-2, 5\n" +
                        "Thread: Thread-2, 4\n" +
                        "Resuming First Thread\n" +
                        "Suspending thread Two\n" +
                        "Thread: Thread-1, 6\n" +
                        "Thread: Thread-1, 5\n" +
                        "Thread: Thread-1, 4\n" +
                        "Thread: Thread-1, 3\n" +
                        "Resuming thread Two\n" +
                        "Thread: Thread-2, 3\n" +
                        "Waiting for threads to finish.\n" +
                        "Thread: Thread-1, 2\n" +
                        "Thread: Thread-2, 2\n" +
                        "Thread: Thread-1, 1\n" +
                        "Thread: Thread-2, 1\n" +
                        "Thread Thread-1 exiting.\n" +
                        "Thread Thread-2 exiting.\n" +
                        "Main thread exiting.");
                put("9-2", "A thread can be in one of the five states. According to sun, there is only 4 states in thread life cycle in java new, runnable, non-runnable and terminated. There is no running state.\n" +
                        "\n" +
                        "But for better understanding the threads, we are explaining it in the 5 states.\n" +
                        "\n" +
                        "The life cycle of the thread in java is controlled by JVM. The java thread states are as follows:\n" +
                        "\n" +
                        "New\n" +
                        "Runnable\n" +
                        "Running\n" +
                        "Non-Runnable (Blocked)\n" +
                        "Terminated\n" +
                        "Java thread life cycle \n" +
                        "\n" +
                        " \n" +
                        "1) New\n" +
                        "The thread is in new state if you create an instance of Thread class but before the invocation of start() method.\n" +
                        "\n" +
                        "2) Runnable\n" +
                        "The thread is in runnable state after invocation of start() method, but the thread scheduler has not selected it to be the running thread.\n" +
                        "\n" +
                        "3) Running\n" +
                        "The thread is in running state if the thread scheduler has selected it.\n" +
                        "\n" +
                        "4) Non-Runnable (Blocked)\n" +
                        "This is the state when the thread is still alive, but is currently not eligible to run.\n" +
                        "\n" +
                        "5) Terminated\n" +
                        "A thread is in terminated or dead state when its run() method exits.");
                put("9-3", "Java Thread Priority in Multithreading\n" +
                        "In a Multi threading environment, thread scheduler assigns processor to a thread based on priority of thread. Whenever we create a thread in Java, it always has some priority assigned to it. Priority can either be given by JVM while creating the thread or it can be given by programmer explicitly.\n" +
                        "Accepted value of priority for a thread is in range of 1 to 10. There are 3 static variables defined in Thread class for priority.\n" +
                        "\n" +
                        "public static int MIN_PRIORITY: This is minimum priority that a thread can have. Value for this is 1.\n" +
                        "public static int NORM_PRIORITY: This is default priority of a thread if do not explicitly define it. Value for this is 5.\n" +
                        "public static int MAX_PRIORITY: This is maximum priority of a thread. Value for this is 10.\n" +
                        "\n" +
                        "Get and Set Thread Priority:\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        " \n" +
                        "\n" +
                        "public final int getPriority(): java.lang.Thread.getPriority() method returns priority of given thread.\n" +
                        "public final void setPriority(int newPriority): java.lang.Thread.setPriority() method changes the priority of thread to the value newPriority. This method throws IllegalArgumentException if value of parameter newPriority goes beyond minimum(1) and maximum(10) limit.");
                put("9-4", "Synchronization in Java\n" +
                        "Synchronization in java is the capability to control the access of multiple threads to any shared resource.\n" +
                        "\n" +
                        "Java Synchronization is better option where we want to allow only one thread to access the shared resource.\n" +
                        "\n" +
                        "Why use Synchronization\n" +
                        "The synchronization is mainly used to\n" +
                        "\n" +
                        "To prevent thread interference.\n" +
                        "To prevent consistency problem.\n" +
                        "Types of Synchronization\n" +
                        "There are two types of synchronization\n" +
                        "\n" +
                        "Process Synchronization\n" +
                        "Thread Synchronization\n" +
                        "Here, we will discuss only thread synchronization.\n" +
                        "\n" +
                        "Thread Synchronization\n" +
                        "There are two types of thread synchronization mutual exclusive and inter-thread communication.\n" +
                        "\n" +
                        "Mutual Exclusive\n" +
                        "Synchronized method.\n" +
                        "Synchronized block.\n" +
                        "static synchronization.\n" +
                        "Cooperation (Inter-thread communication in java)\n" +
                        "\n" +
                        " \n" +
                        "Mutual Exclusive\n" +
                        "Mutual Exclusive helps keep threads from interfering with one another while sharing data. This can be done by three ways in java:\n" +
                        "\n" +
                        "by synchronized method\n" +
                        "by synchronized block\n" +
                        "by static synchronization\n");
                put("9-5", "Runnable interface in Java\n" +
                        "java.lang.Runnable is an interface that is to be implemented by a class whose instances are intended to be executed by a thread. There are two ways to start a new Thread – Subclass Thread and implement Runnable. There is no need of subclassing Thread when a task can be done by overriding only run() method of Runnable.\n" +
                        "\n" +
                        "Steps to create a new Thread using Runnable :\n" +
                        "1. Create a Runnable implementer and implement run() method.\n" +
                        "2. Instantiate Thread class and pass the implementer to the Thread, Thread has a constructor which accepts Runnable instance.\n" +
                        "3. Invoke start() of Thread instance, start internally calls run() of the implementer. Invoking start(), creates a new Thread which executes the code written in run().\n" +
                        "Calling run() directly doesn’t create and start a new Thread, it will run in the same thread. To start a new line of execution, call start() on the thread.");

                //////////////////////////////////////////////////////////////////////////////////////
                put("10-0", "An exception (or exceptional event) is a problem that arises during the execution of a program. When an Exception occurs the normal flow of the program is disrupted and the program/Application terminates abnormally, which is not recommended, therefore, these exceptions are to be handled.\n" +
                        "\n" +
                        "An exception can occur for many different reasons. Following are some scenarios where an exception occurs.\n" +
                        "\n" +
                        "A user has entered an invalid data.\n" +
                        "\n" +
                        "A file that needs to be opened cannot be found.\n" +
                        "\n" +
                        "A network connection has been lost in the middle of communications or the JVM has run out of memory.\n" +
                        "\n" +
                        "Some of these exceptions are caused by user error, others by programmer error, and others by physical resources that have failed in some manner.\n" +
                        "\n" +
                        "Based on these, we have three categories of Exceptions. You need to understand them to know how exception handling works in Java.\n" +
                        "\n" +
                        "Checked exceptions − A checked exception is an exception that is checked (notified) by the compiler at compilation-time, these are also called as compile time exceptions. These exceptions cannot simply be ignored, the programmer should take care of (handle) these exceptions.\n" +
                        "\n" +
                        "For example, if you use FileReader class in your program to read data from a file, if the file specified in its constructor doesn't exist, then a FileNotFoundException occurs, and the compiler prompts the programmer to handle the exception.\n" +
                        "\n" +
                        "Example\n" +
                        " Live Demo\n" +
                        "import java.io.File;\n" +
                        "import java.io.FileReader;\n" +
                        "\n" +
                        "public class FilenotFound_Demo {\n" +
                        "\n" +
                        "   public static void main(String args[]) {\t\t\n" +
                        "      File file = new File(\"E://file.txt\");\n" +
                        "      FileReader fr = new FileReader(file); \n" +
                        "   }\n" +
                        "}\n" +
                        "If you try to compile the above program, you will get the following exceptions.\n" +
                        "\n" +
                        "Output\n" +
                        "C:\\>javac FilenotFound_Demo.java\n" +
                        "FilenotFound_Demo.java:8: error: unreported exception FileNotFoundException; must be caught or declared to be thrown\n" +
                        "      FileReader fr = new FileReader(file);\n" +
                        "                      ^\n" +
                        "1 error");
                put("10-1", "Java try-catch\n" +
                        "Java try block\n" +
                        "Java try block is used to enclose the code that might throw an exception. It must be used within the method.\n" +
                        "\n" +
                        "Java try block must be followed by either catch or finally block.\n" +
                        "\n" +
                        "Syntax of java try-catch\n" +
                        "try{  \n" +
                        "//code that may throw exception  \n" +
                        "}catch(Exception_class_Name ref){}  \n" +
                        "Syntax of try-finally block\n" +
                        "try{  \n" +
                        "//code that may throw exception  \n" +
                        "}finally{}  \n" +
                        "\n" +
                        " \n" +
                        "Java catch block\n" +
                        "Java catch block is used to handle the Exception. It must be used after the try block only.\n" +
                        "\n" +
                        "You can use multiple catch block with a single try.\n" +
                        "\n" +
                        "Problem without exception handling\n" +
                        "Let's try to understand the problem if we don't use try-catch block.\n" +
                        "\n" +
                        "public class Testtrycatch1{  \n" +
                        "  public static void main(String args[]){  \n" +
                        "      int data=50/0;//may throw exception  \n" +
                        "      System.out.println(\"rest of the code...\");  \n" +
                        "}  \n" +
                        "}  " +
                        "Output:\n" +
                        "\n" +
                        "Exception in thread main java.lang.ArithmeticException:/ by zero");
                put("10-2", "Java Custom Exception\n" +
                        "If you are creating your own Exception that is known as custom exception or user-defined exception. Java custom exceptions are used to customize the exception according to user need.\n" +
                        "\n" +
                        "By the help of custom exception, you can have your own exception and message.\n" +
                        "\n" +
                        "Let's see a simple example of java custom exception.\n" +
                        "\n" +
                        "class InvalidAgeException extends Exception{  \n" +
                        " InvalidAgeException(String s){  \n" +
                        "  super(s);  \n" +
                        " }  \n" +
                        "}  \n" +
                        "class TestCustomException1{  \n" +
                        "  \n" +
                        "   static void validate(int age)throws InvalidAgeException{  \n" +
                        "     if(age<18)  \n" +
                        "      throw new InvalidAgeException(\"not valid\");  \n" +
                        "     else  \n" +
                        "      System.out.println(\"welcome to vote\");  \n" +
                        "   }  \n" +
                        "     \n" +
                        "   public static void main(String args[]){  \n" +
                        "      try{  \n" +
                        "      validate(13);  \n" +
                        "      }catch(Exception m){System.out.println(\"Exception occured: \"+m);}  \n" +
                        "  \n" +
                        "      System.out.println(\"rest of the code...\");  \n" +
                        "  }  \n" +
                        "}  " +
                        "Output:Exception occured: InvalidAgeException:not valid\n" +
                        "       rest of the code...\n");

                ///////////////////////////////////////////////////////////
                put("11-0", "The java.io package contains nearly every class you might ever need to perform input and output (I/O) in Java. All these streams represent an input source and an output destination. The stream in the java.io package supports many data such as primitives, object, localized characters, etc.\n" +
                        "\n" +
                        "Stream\n" +
                        "A stream can be defined as a sequence of data. There are two kinds of Streams −\n" +
                        "\n" +
                        "InPutStream − The InputStream is used to read data from a source.\n" +
                        "\n" +
                        "OutPutStream − The OutputStream is used for writing data to a destination.\n" +
                        "\n" +
                        "Streams\n" +
                        "Java provides strong but flexible support for I/O related to files and networks but this tutorial covers very basic functionality related to streams and I/O. ");
                put("11-1", "Byte Streams\n" +
                        "Java byte streams are used to perform input and output of 8-bit bytes. Though there are many classes related to byte streams but the most frequently used classes are, FileInputStream and FileOutputStream. Following is an example which makes use of these two classes to copy an input file into an output file −\n" +
                        "\n" +
                        "Example\n" +
                        "\n" +
                        "import java.io.*;\n" +
                        "public class CopyFile {\n" +
                        "\n" +
                        "   public static void main(String args[]) throws IOException {  \n" +
                        "      FileInputStream in = null;\n" +
                        "      FileOutputStream out = null;\n" +
                        "\n" +
                        "      try {\n" +
                        "         in = new FileInputStream(\"input.txt\");\n" +
                        "         out = new FileOutputStream(\"output.txt\");\n" +
                        "         \n" +
                        "         int c;\n" +
                        "         while ((c = in.read()) != -1) {\n" +
                        "            out.write(c);\n" +
                        "         }\n" +
                        "      }finally {\n" +
                        "         if (in != null) {\n" +
                        "            in.close();\n" +
                        "         }\n" +
                        "         if (out != null) {\n" +
                        "            out.close();\n" +
                        "         }\n" +
                        "      }\n" +
                        "   }\n" +
                        "}\n" +
                        "Now let's have a file input.txt with the following content −\n" +
                        "\n" +
                        "This is test for copy file.\n" +
                        "As a next step, compile the above program and execute it, which will result in creating output.txt file with the same content as we have in input.txt. So let's put the above code in CopyFile.java file and do the following −\n" +
                        "\n" +
                        "$javac CopyFile.java\n" +
                        "$java CopyFile");
                put("11-2", "Character Streams\n" +
                        "Java Byte streams are used to perform input and output of 8-bit bytes, whereas Java Character streams are used to perform input and output for 16-bit unicode. Though there are many classes related to character streams but the most frequently used classes are, FileReader and FileWriter. Though internally FileReader uses FileInputStream and FileWriter uses FileOutputStream but here the major difference is that FileReader reads two bytes at a time and FileWriter writes two bytes at a time.\n" +
                        "\n" +
                        "We can re-write the above example, which makes the use of these two classes to copy an input file (having unicode characters) into an output file −\n" +
                        "\n" +
                        "Example\n" +
                        "\n" +
                        "import java.io.*;\n" +
                        "public class CopyFile {\n" +
                        "\n" +
                        "   public static void main(String args[]) throws IOException {\n" +
                        "      FileReader in = null;\n" +
                        "      FileWriter out = null;\n" +
                        "\n" +
                        "      try {\n" +
                        "         in = new FileReader(\"input.txt\");\n" +
                        "         out = new FileWriter(\"output.txt\");\n" +
                        "         \n" +
                        "         int c;\n" +
                        "         while ((c = in.read()) != -1) {\n" +
                        "            out.write(c);\n" +
                        "         }\n" +
                        "      }finally {\n" +
                        "         if (in != null) {\n" +
                        "            in.close();\n" +
                        "         }\n" +
                        "         if (out != null) {\n" +
                        "            out.close();\n" +
                        "         }\n" +
                        "      }\n" +
                        "   }\n" +
                        "}\n" +
                        "Now let's have a file input.txt with the following content −\n" +
                        "\n" +
                        "This is test for copy file.\n" +
                        "As a next step, compile the above program and execute it, which will result in creating output.txt file with the same content as we have in input.txt. So let's put the above code in CopyFile.java file and do the following −\n" +
                        "\n" +
                        "$javac CopyFile.java\n" +
                        "$java CopyFile");
                put("11-3", "Standard Streams\n" +
                        "All the programming languages provide support for standard I/O where the user's program can take input from a keyboard and then produce an output on the computer screen. If you are aware of C or C++ programming languages, then you must be aware of three standard devices STDIN, STDOUT and STDERR. Similarly, Java provides the following three standard streams −\n" +
                        "\n" +
                        "Standard Input − This is used to feed the data to user's program and usually a keyboard is used as standard input stream and represented as System.in.\n" +
                        "\n" +
                        "Standard Output − This is used to output the data produced by the user's program and usually a computer screen is used for standard output stream and represented as System.out.\n" +
                        "\n" +
                        "Standard Error − This is used to output the error data produced by the user's program and usually a computer screen is used for standard error stream and represented as System.err.\n" +
                        "\n" +
                        "Following is a simple program, which creates InputStreamReader to read standard input stream until the user types a \"q\" −\n" +
                        "\n" +
                        "Example\n" +
                        "\n" +
                        " Live Demo\n" +
                        "import java.io.*;\n" +
                        "public class ReadConsole {\n" +
                        "\n" +
                        "   public static void main(String args[]) throws IOException {\n" +
                        "      InputStreamReader cin = null;\n" +
                        "\n" +
                        "      try {\n" +
                        "         cin = new InputStreamReader(System.in);\n" +
                        "         System.out.println(\"Enter characters, 'q' to quit.\");\n" +
                        "         char c;\n" +
                        "         do {\n" +
                        "            c = (char) cin.read();\n" +
                        "            System.out.print(c);\n" +
                        "         } while(c != 'q');\n" +
                        "      }finally {\n" +
                        "         if (cin != null) {\n" +
                        "            cin.close();\n" +
                        "         }\n" +
                        "      }\n" +
                        "   }\n" +
                        "}\n" +
                        "Let's keep the above code in ReadConsole.java file and try to compile and execute it as shown in the following program. This program continues to read and output the same character until we press 'q' −\n" +
                        "\n" +
                        "$javac ReadConsole.java\n" +
                        "$java ReadConsole\n" +
                        "Enter characters, 'q' to quit.\n" +
                        "1\n" +
                        "1\n" +
                        "e\n" +
                        "e\n" +
                        "q\n" +
                        "q");
                put("11-4", "Java.io.File Class in Java\n" +
                        "The File class is Java’s representation of a file or directory path name. Because file and directory names have different formats on different platforms, a simple string is not adequate to name them. The File class contains several methods for working with the path name, deleting and renaming files, creating new directories, listing the contents of a directory, and determining several common attributes of files and directories.\n" +
                        "\n" +
                        "It is an abstract representation of file and directory pathnames.\n" +
                        "A pathname, whether abstract or in string form can be either absolute or relative. The parent of an abstract pathname may be obtained by invoking the getParent() method of this class.\n" +
                        "First of all, we should create the File class object by passing the filename or directory name to it. A file system may implement restrictions to certain operations on the actual file-system object, such as reading, writing, and executing. These restrictions are collectively known as access permissions.\n" +
                        "Instances of the File class are immutable; that is, once created, the abstract pathname represented by a File object will never change.\n" +
                        "How to create a File Object?\n" +
                        "A File object is created by passing in a String that represents the name of a file, or a String or another File object. For example,\n" +
                        "\n" +
                        " File a = new File(\"/usr/local/bin/geeks\");\n" +
                        "defines an abstract file name for the geeks file in directory /usr/local/bin. This is an absolute abstract file name.\n" +
                        "\n" +
                        "Constructors \n" +
                        "\n" +
                        "File(File parent, String child) : Creates a new File instance from a parent abstract pathname and a child pathname string.\n" +
                        "File(String pathname) : Creates a new File instance by converting the given pathname string into an abstract pathname.\n" +
                        "File(String parent, String child) : Creates a new File instance from a parent pathname string and a child pathname string.\n" +
                        "File(URI uri) : Creates a new File instance by converting the given file: URI into an abstract pathname.");
                put("11-5", "Directories in Java\n" +
                        "A directory is a File which can contain a list of other files and directories. You use File object to create directories, to list down files available in a directory. For complete detail, check a list of all the methods which you can call on File object and what are related to directories.\n" +
                        "\n" +
                        "Creating Directories\n" +
                        "There are two useful File utility methods, which can be used to create directories −\n" +
                        "\n" +
                        "The mkdir( ) method creates a directory, returning true on success and false on failure. Failure indicates that the path specified in the File object already exists, or that the directory cannot be created because the entire path does not exist yet.\n" +
                        "\n" +
                        "The mkdirs() method creates both a directory and all the parents of the directory.\n" +
                        "\n" +
                        "Following example creates \"/tmp/user/java/bin\" directory −\n" +
                        "\n" +
                        "Example\n" +
                        "\n" +
                        "import java.io.File;\n" +
                        "public class CreateDir {\n" +
                        "\n" +
                        "   public static void main(String args[]) {\n" +
                        "      String dirname = \"/tmp/user/java/bin\";\n" +
                        "      File d = new File(dirname);\n" +
                        "      \n" +
                        "      // Create directory now.\n" +
                        "      d.mkdirs();\n" +
                        "   }\n" +
                        "}\n" +
                        "Compile and execute the above code to create \"/tmp/user/java/bin\".\n" +
                        "\n" +
                        "Note − Java automatically takes care of path separators on UNIX and Windows as per conventions. If you use a forward slash (/) on a Windows version of Java, the path will still resolve correctly.\n" +
                        "\n" +
                        "Listing Directories\n" +
                        "You can use list( ) method provided by File object to list down all the files and directories available in a directory as follows −\n" +
                        "\n" +
                        "Example\n" +
                        "\n" +
                        "import java.io.File;\n" +
                        "public class ReadDir {\n" +
                        "\n" +
                        "   public static void main(String[] args) {\n" +
                        "      File file = null;\n" +
                        "      String[] paths;\n" +
                        "  \n" +
                        "      try {      \n" +
                        "         // create new file object\n" +
                        "         file = new File(\"/tmp\");\n" +
                        "\n" +
                        "         // array of files and directory\n" +
                        "         paths = file.list();\n" +
                        "\n" +
                        "         // for each name in the path array\n" +
                        "         for(String path:paths) {\n" +
                        "            // prints filename and directory name\n" +
                        "            System.out.println(path);\n" +
                        "         }\n" +
                        "      } catch (Exception e) {\n" +
                        "         // if any error occurs\n" +
                        "         e.printStackTrace();\n" +
                        "      }\n" +
                        "   }\n" +
                        "}\n" +
                        "This will produce the following result based on the directories and files available in your /tmp directory −\n" +
                        "\n" +
                        "Output\n" +
                        "\n" +
                        "test1.txt\n" +
                        "test2.txt\n" +
                        "ReadDir.java\n" +
                        "ReadDir.class");
            }});

            /////////////---------------------------------//////////////////////////
            put("programs", new HashMap<String, String>(){{
                put("0", "Hello World Program:\n" +
                        "\n" +
                        "class Simple{  \n" +
                        "    public static void main(String args[]){  \n" +
                        "     System.out.println(\"Hello Java\");  \n" +
                        "    }  \n" +
                        "}  \n" +
                        "\n" +
                        "\n" +
                        "Output:Hello Java");
                put("1", "If Else Statement:\n" +
                        "\n" +
                        "//Java Program to demonstate the use of if statement.  \n" +
                        "public class IfExample {  \n" +
                        "public static void main(String[] args) {  \n" +
                        "    //defining an 'age' variable  \n" +
                        "    int age=20;  \n" +
                        "    //checking the age  \n" +
                        "    if(age>18){  \n" +
                        "        System.out.print(\"Age is greater than 18\");  \n" +
                        "    }  \n" +
                        "}  \n" +
                        "}  \n" +
                        "\n" +
                        "\n" +
                        "Output:Age is greater than 18\");\n");
                put("2","While Loop:\n" +
                        "\n" +
                        "public class WhileExample {  \n" +
                        "public static void main(String[] args) {  \n" +
                        "    int i=1;  \n" +
                        "    while(i<=10){  \n" +
                        "        System.out.println(i);  \n" +
                        "    i++;  \n" +
                        "    }  \n" +
                        "}  \n" +
                        "}  \n" +
                        "\n" +
                        "\n" +
                        "Output: 1\n" +
                        "\t2\n" +
                        "\t3\n" +
                        "\t4\n" +
                        "\t5\n" +
                        "\t6\n" +
                        "\t7\n" +
                        "\t8\n" +
                        "\t9\n" +
                        "\t10");
                put("3", "Do While Loop:\n" +
                        "\n" +
                        "public class DoWhileExample {  \n" +
                        "public static void main(String[] args) {  \n" +
                        "    int i=1;  \n" +
                        "    do{  \n" +
                        "        System.out.println(i);  \n" +
                        "    i++;  \n" +
                        "    }while(i<=10);  \n" +
                        "}  \n" +
                        "}  \n" +
                        "\n" +
                        "\n" +
                        "Output: 1\n" +
                        "\t2\n" +
                        "\t3\n" +
                        "\t4\n" +
                        "\t5\n" +
                        "\t6\n" +
                        "\t7\n" +
                        "\t8\n" +
                        "\t9\n" +
                        "\t10");
                put("4", "For Loop:\n" +
                        "\n" +
                        "public class LabeledForExample2 {  \n" +
                        "public static void main(String[] args) {  \n" +
                        "    aa:  \n" +
                        "        for(int i=1;i<=3;i++){  \n" +
                        "            bb:  \n" +
                        "                for(int j=1;j<=3;j++){  \n" +
                        "                    if(i==2&&j==2){  \n" +
                        "                        break bb;  \n" +
                        "                    }  \n" +
                        "                    System.out.println(i+\" \"+j);  \n" +
                        "                }  \n" +
                        "        }  \n" +
                        "}  \n" +
                        "}  \n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "Output: 1 1\n" +
                        "\t1 2\n" +
                        "\t1 3\n" +
                        "\t2 1\n" +
                        "\t3 1\n" +
                        "\t3 2\n" +
                        "\t3 3");
                put("5", "Switch Loop:\n" +
                        "\n" +
                        "//Java Program to demonstrate the example of Switch statement  \n" +
                        "//where we are printing month name for the given number  \n" +
                        "public class SwitchMonthExample {    \n" +
                        "public static void main(String[] args) {    \n" +
                        "    //Specifying month number  \n" +
                        "    int month=7;    \n" +
                        "    String monthString=\"\";  \n" +
                        "    //Switch statement  \n" +
                        "    switch(month){    \n" +
                        "    //case statements within the switch block  \n" +
                        "    case 1: monthString=\"1 - January\";  \n" +
                        "    break;    \n" +
                        "    case 2: monthString=\"2 - February\";  \n" +
                        "    break;    \n" +
                        "    case 3: monthString=\"3 - March\";  \n" +
                        "    break;    \n" +
                        "    case 4: monthString=\"4 - April\";  \n" +
                        "    break;    \n" +
                        "    case 5: monthString=\"5 - May\";  \n" +
                        "    break;    \n" +
                        "    case 6: monthString=\"6 - June\";  \n" +
                        "    break;    \n" +
                        "    case 7: monthString=\"7 - July\";  \n" +
                        "    break;    \n" +
                        "    case 8: monthString=\"8 - August\";  \n" +
                        "    break;    \n" +
                        "    case 9: monthString=\"9 - September\";  \n" +
                        "    break;    \n" +
                        "    case 10: monthString=\"10 - October\";  \n" +
                        "    break;    \n" +
                        "    case 11: monthString=\"11 - November\";  \n" +
                        "    break;    \n" +
                        "    case 12: monthString=\"12 - December\";  \n" +
                        "    break;    \n" +
                        "    default:System.out.println(\"Invalid Month!\");    \n" +
                        "    }    \n" +
                        "    //Printing month of the given number  \n" +
                        "    System.out.println(monthString);  \n" +
                        "}    \n" +
                        "}   \n" +
                        "\n" +
                        "\n" +
                        "Output:7 - July");
                put("6", "Continue Statement:\n" +
                        "\n" +
                        "//Java Program to illustrate the use of continue statement  \n" +
                        "//inside an inner loop  \n" +
                        "public class ContinueExample2 {  \n" +
                        "public static void main(String[] args) {  \n" +
                        "            //outer loop  \n" +
                        "            for(int i=1;i<=3;i++){    \n" +
                        "                    //inner loop  \n" +
                        "                    for(int j=1;j<=3;j++){    \n" +
                        "                        if(i==2&&j==2){    \n" +
                        "                            //using continue statement inside inner loop  \n" +
                        "                            continue;    \n" +
                        "                        }    \n" +
                        "                        System.out.println(i+\" \"+j);    \n" +
                        "                    }    \n" +
                        "            }    \n" +
                        "\t}  \n" +
                        "     }\n" +
                        "\n" +
                        "\n" +
                        "Output: 1 1\n" +
                        "\t1 2\n" +
                        "\t1 3\n" +
                        "\t2 1\n" +
                        "\t2 3\n" +
                        "\t3 1\n" +
                        "\t3 2\n" +
                        "\t3 3");
                put("7", "Even and Odd:\n" +
                        "\n" +
                        "public class OddEvenInArrayExample{  \n" +
                        "public static void main(String args[]){  \n" +
                        "int a[]={1,2,5,6,3,2};  \n" +
                        "System.out.println(\"Odd Numbers:\");  \n" +
                        "for(int i=0;i<a.length;i++){  \n" +
                        "if(a[i]%2!=0){  \n" +
                        "System.out.println(a[i]);  \n" +
                        "}  \n" +
                        "}  \n" +
                        "System.out.println(\"Even Numbers:\");  \n" +
                        "for(int i=0;i<a.length;i++){  \n" +
                        "if(a[i]%2==0){  \n" +
                        "System.out.println(a[i]);  \n" +
                        "}  \n" +
                        "}  \n" +
                        "}}  \n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "Output:Odd Numbers:\n" +
                        "\t1\n" +
                        "\t5\n" +
                        "\t3\n" +
                        "       Even Numbers:\n" +
                        "\t2\n" +
                        "\t6\n" +
                        "\t2");
                put("8", "Largest of three numbers:\n" +
                        "\n" +
                        "public class Largest {\n" +
                        "\n" +
                        "    public static void main(String[] args) {\n" +
                        "\n" +
                        "        double n1 = -4.5, n2 = 3.9, n3 = 2.5;\n" +
                        "\n" +
                        "        if( n1 >= n2 && n1 >= n3)\n" +
                        "            System.out.println(n1 + \" is the largest number.\");\n" +
                        "\n" +
                        "        else if (n2 >= n1 && n2 >= n3)\n" +
                        "            System.out.println(n2 + \" is the largest number.\");\n" +
                        "\n" +
                        "        else\n" +
                        "            System.out.println(n3 + \" is the largest number.\");\n" +
                        "    }\n" +
                        "}\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "Output: 3.9 is the largest number.\n");
                put("9", "Prime Number:\n" +
                        "\n" +
                        "public class PrimeExample{    \n" +
                        " public static void main(String args[]){    \n" +
                        "  int i,m=0,flag=0;      \n" +
                        "  int n=3;//it is the number to be checked    \n" +
                        "  m=n/2;      \n" +
                        "  if(n==0||n==1){  \n" +
                        "   System.out.println(n+\" is not prime number\");      \n" +
                        "  }else{  \n" +
                        "   for(i=2;i<=m;i++){      \n" +
                        "    if(n%i==0){      \n" +
                        "     System.out.println(n+\" is not prime number\");      \n" +
                        "     flag=1;      \n" +
                        "     break;      \n" +
                        "    }      \n" +
                        "   }      \n" +
                        "   if(flag==0)  { System.out.println(n+\" is prime number\"); }  \n" +
                        "  }//end of else  \n" +
                        "}    \n" +
                        "}   \n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "Output:3 is prime number");
                put("10", "Palindrome:\n" +
                        "\n" +
                        "class PalindromeExample{  \n" +
                        " public static void main(String args[]){  \n" +
                        "  int r,sum=0,temp;    \n" +
                        "  int n=454;//It is the number variable to be checked for palindrome  \n" +
                        "  \n" +
                        "  temp=n;    \n" +
                        "  while(n>0){    \n" +
                        "   r=n%10;  //getting remainder  \n" +
                        "   sum=(sum*10)+r;    \n" +
                        "   n=n/10;    \n" +
                        "  }    \n" +
                        "  if(temp==sum)    \n" +
                        "   System.out.println(\"palindrome number \");    \n" +
                        "  else    \n" +
                        "   System.out.println(\"not palindrome\");    \n" +
                        "}  \n" +
                        "}  \n" +
                        "\n" +
                        "Output: palindrome  number");
                put("11", "Factorial:\n" +
                        "\n" +
                        "class FactorialExample{  \n" +
                        " public static void main(String args[]){  \n" +
                        "  int i,fact=1;  \n" +
                        "  int number=5;//It is the number to calculate factorial    \n" +
                        "  for(i=1;i<=number;i++){    \n" +
                        "      fact=fact*i;    \n" +
                        "  }    \n" +
                        "  System.out.println(\"Factorial of \"+number+\" is: \"+fact);    \n" +
                        " }  \n" +
                        "}  \n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "Output:Factorial of 5 is: 120");
                put("12", "");
                put("13", "Simple Interest:\n" +
                        "\n" +
                        "public class Main  \n" +
                        " {  \n" +
                        "   public static void main (String args[])  \n" +
                        "    {   float p, r,  t,  si; // principal amount, rate, time and simple interest respectively  \n" +
                        "              p = 13000;  r = 12; t = 2;  \n" +
                        "               si  = (p*r*t)/100;   \n" +
                        "              System.out.println(\"Simple Interest is: \" +si);  \n" +
                        "    }}  \n" +
                        "\n" +
                        "Output:Simple Interest is:  3120.0");
                put("14", "Calculate Percentage:\n" +
                        "\n" +
                        "public class Percentage {\n" +
                        "   public static void main(String args[]){\n" +
                        "      float percentage;\n" +
                        "      float total_marks;\n" +
                        "      float scored;\n" +
                        "      Scanner sc = new Scanner(System.in);\n" +
                        "      System.out.println(\"Enter your marks ::\");\n" +
                        "      scored = sc.nextFloat();\n" +
                        "\n" +
                        "      System.out.println(\"Enter total marks ::\");\n" +
                        "      total_marks = sc.nextFloat();\n" +
                        "\n" +
                        "      percentage = (float)((scored / total_marks) * 100);\n" +
                        "      System.out.println(\"Percentage ::\"+ percentage);\n" +
                        "   }\n" +
                        "}\n" +
                        "\n" +
                        "\n" +
                        "Output: Enter your marks ::\n" +
                        "\t500\n" +
                        "        Enter total marks ::\n" +
                        "\t600\n" +
                        "\tPercentage ::83.33333");
                put("15", "GCD and LCM:\n" +
                        "\n" +
                        "public class LCM_GCD {\n" +
                        "   public static void lcm(int a, int b){\n" +
                        "      int max, step, lcm = 0;\n" +
                        "      if(a > b){\n" +
                        "         max = step = a;\n" +
                        "      } else{\n" +
                        "         max = step = b;\n" +
                        "      }\n" +
                        "      while(a!= 0) {\n" +
                        "         if(max%a == 0 && max%b == 0) {\n" +
                        "            lcm = max;\n" +
                        "            break;\n" +
                        "         }\n" +
                        "         max += step;\n" +
                        "      }\n" +
                        "      System.out.println(\"LCM of given numbers is :: \"+lcm);\n" +
                        "   }\n" +
                        "   public static void gcd(int a,int b){\n" +
                        "      int i, hcf = 0;\n" +
                        "         for(i = 1; i <= a || i <= b; i++) {\n" +
                        "            if( a%i == 0 && b%i == 0 )\n" +
                        "            hcf = i;\n" +
                        "         }\n" +
                        "         System.out.println(\"gcd of given two numbers is ::\"+hcf);\n" +
                        "   }\n" +
                        "   public static void main(String args[]){\n" +
                        "      Scanner sc = new Scanner(System.in);\n" +
                        "      System.out.println(\"Enter first number ::\");\n" +
                        "      int a = sc.nextInt();\n" +
                        "      System.out.println(\"Enter second number ::\");\n" +
                        "      int b = sc.nextInt();\n" +
                        "      lcm(a, b);\n" +
                        "      gcd(a,b);\n" +
                        "   }\n" +
                        "}\n" +
                        "\n" +
                        "\n" +
                        "Output:Enter first number ::\n" +
                        "\t125\n" +
                        "       Enter second number ::\n" +
                        "\t25\n" +
                        "       LCM of given numbers is :: 125\n" +
                        "       GCD of given two numbers is ::25");
                put("16", "Leap Year:\n" +
                        "\n" +
                        "public class LeapYear {\n" +
                        "\n" +
                        "    public static void main(String[] args) {\n" +
                        "\n" +
                        "        int year = 1900;\n" +
                        "        boolean leap = false;\n" +
                        "\n" +
                        "        if(year % 4 == 0)\n" +
                        "        {\n" +
                        "            if( year % 100 == 0)\n" +
                        "            {\n" +
                        "                // year is divisible by 400, hence the year is a leap year\n" +
                        "                if ( year % 400 == 0)\n" +
                        "                    leap = true;\n" +
                        "                else\n" +
                        "                    leap = false;\n" +
                        "            }\n" +
                        "            else\n" +
                        "                leap = true;\n" +
                        "        }\n" +
                        "        else\n" +
                        "            leap = false;\n" +
                        "\n" +
                        "        if(leap)\n" +
                        "            System.out.println(year + \" is a leap year.\");\n" +
                        "        else\n" +
                        "            System.out.println(year + \" is not a leap year.\");\n" +
                        "    }\n" +
                        "}\n" +
                        "\n" +
                        "\n" +
                        "\n" +
                        "Output:1900 is not a leap year.");
                put("17", "Print Tables:\n" +
                        "\n" +
                        "public class Multiplication_Table \n" +
                        "{\n" +
                        "    public static void main(String[] args) \n" +
                        "    {\n" +
                        "        Scanner s = new Scanner(System.in);\n" +
                        "\tSystem.out.print(\"Enter number:\");        \n" +
                        "\tint n=s.nextInt();\n" +
                        "        for(int i=1; i <= 10; i++)\n" +
                        "        {\n" +
                        "            System.out.println(n+\" * \"+i+\" = \"+n*i);\n" +
                        "        }\n" +
                        "    }\n" +
                        "}\n" +
                        "\n" +
                        "\n" +
                        "Output:\n" +
                        "Enter number:7\n" +
                        "7 * 1 = 7\n" +
                        "7 * 2 = 14\n" +
                        "7 * 3 = 21\n" +
                        "7 * 4 = 28\n" +
                        "7 * 5 = 35\n" +
                        "7 * 6 = 42\n" +
                        "7 * 7 = 49\n" +
                        "7 * 8 = 56\n" +
                        "7 * 9 = 63\n" +
                        "7 * 10 = 70");
                put("18", "Find Amstrong Number:\n" +
                        "\n" +
                        "public class Armstrong {\n" +
                        "\n" +
                        "    public static void main(String[] args) {\n" +
                        "\n" +
                        "        int low = 999, high = 99999;\n" +
                        "\n" +
                        "        for(int number = low + 1; number < high; ++number) {\n" +
                        "            int digits = 0;\n" +
                        "            int result = 0;\n" +
                        "            int originalNumber = number;\n" +
                        "\n" +
                        "            // number of digits calculation\n" +
                        "            while (originalNumber != 0) {\n" +
                        "                originalNumber /= 10;\n" +
                        "                ++digits;\n" +
                        "            }\n" +
                        "\n" +
                        "            originalNumber = number;\n" +
                        "\n" +
                        "            // result contains sum of nth power of its digits\n" +
                        "            while (originalNumber != 0) {\n" +
                        "                int remainder = originalNumber % 10;\n" +
                        "                result += Math.pow(remainder, digits);\n" +
                        "                originalNumber /= 10;\n" +
                        "            }\n" +
                        "\n" +
                        "            if (result == number)\n" +
                        "                System.out.print(number + \" \");\n" +
                        "        }\n" +
                        "    }\n" +
                        "}\n" +
                        "\n" +
                        "\n" +
                        "Output: 1634 8208 9474 54748 92727 93084 ");
                put("19", "Swapping Two Numbers:\n" +
                        "\n" +
                        "public class SwapNumbers {\n" +
                        "\n" +
                        "    public static void main(String[] args) {\n" +
                        "\n" +
                        "        float first = 1.20f, second = 2.45f;\n" +
                        "\n" +
                        "        System.out.println(\"--Before swap--\");\n" +
                        "        System.out.println(\"First number = \" + first);\n" +
                        "        System.out.println(\"Second number = \" + second);\n" +
                        "\n" +
                        "        // Value of first is assigned to temporary\n" +
                        "        float temporary = first;\n" +
                        "\n" +
                        "        // Value of second is assigned to first\n" +
                        "        first = second;\n" +
                        "\n" +
                        "        // Value of temporary (which contains the initial value of first) is assigned to second\n" +
                        "        second = temporary;\n" +
                        "\n" +
                        "        System.out.println(\"--After swap--\");\n" +
                        "        System.out.println(\"First number = \" + first);\n" +
                        "        System.out.println(\"Second number = \" + second);\n" +
                        "    }\n" +
                        "}\n" +
                        "\n" +
                        "\n" +
                        "Output:\n" +
                        "--Before swap--\n" +
                        "First number = 1.2\n" +
                        "Second number = 2.45\n" +
                        "--After swap--\n" +
                        "First number = 2.45\n" +
                        "Second number = 1.2");
                put("20", "Flyods Triangle:\n" +
                        "\n" +
                        "public class FloydTriangle { public static void main(String args[]) \n" +
                        "\t{\n" +
                        " \tScanner cmd = new Scanner(System.in); \n" +
                        "\tSystem.out.println(\"Enter the number of rows of Floyd's triangle, you want to display\");\n" +
                        "\tint rows = cmd.nextInt(); \n" +
                        "\tprintFloydTriangle(rows); \n" +
                        "\t} \n" +
                        "\tpublic static void printFloydTriangle(int rows)\n" +
                        "\t { \n" +
                        "\t\tint number = 1;\n" +
                        "\t\tSystem.out.printf(\"Floyd's triangle of %d rows is : %n\", rows);\n" +
                        "\t\tfor (int i = 1; i <= rows; i++)\n" +
                        " \t\t{\n" +
                        "\t \t\tfor (int j = 1; j <= i; j++) \n" +
                        "\t\t\t{ \n" +
                        "\t\t\t\tSystem.out.print(number + \" \");\n" +
                        "\t\t\t\t number++;\n" +
                        "\t\t\t} System.out.println(); \n" +
                        "\t\t}\t\n" +
                        " \t}\n" +
                        " }\n" +
                        "\n" +
                        "\n" +
                        "Output:\n" +
                        "Enter the number of rows of Floyd's triangle, you want to display\n" +
                        "5\n" +
                        "Floyd's triangle of 5 rows is :\n" +
                        "1\n" +
                        "2 3\n" +
                        "4 5 6 \n" +
                        "7 8 9 10 \n" +
                        "11 12 13 14 15\n");
                put("21", "Pascal Triangle:\n" +
                        "\n" +
                        "public class PascalsTriangle {\n" +
                        "   static int factorial(int n) {\n" +
                        "      int f;\n" +
                        "\n" +
                        "      for(f = 1; n > 1; n--){\n" +
                        "         f *= n;\n" +
                        "      }\n" +
                        "      return f;\n" +
                        "   }\n" +
                        "   static int ncr(int n,int r) {\n" +
                        "      return factorial(n) / ( factorial(n-r) * factorial(r) );\n" +
                        "   }\n" +
                        "   public static void main(String args[]){\n" +
                        "      System.out.println();\n" +
                        "      int n, i, j;\n" +
                        "      n = 5;\n" +
                        "\n" +
                        "      for(i = 0; i <= n; i++) {\n" +
                        "         for(j = 0; j <= n-i; j++){\n" +
                        "            System.out.print(\" \");\n" +
                        "         }\n" +
                        "         for(j = 0; j <= i; j++){\n" +
                        "            System.out.print(\" \"+ncr(i, j));\n" +
                        "         }\n" +
                        "         System.out.println();\n" +
                        "      }\n" +
                        "   }\n" +
                        "}\n" +
                        "\n" +
                        "\n" +
                        "Output:\n" +
                        "    \t     1\n" +
                        "          1     1\n" +
                        "        1    2    1\n" +
                        "      1    3   3     1\n" +
                        "   1    4     6    4    1\n" +
                        "1   5   10     10    5    1");
                put("22", "Binary to Decimal:\n" +
                        "\n" +
                        "public class BinaryToDecimalExample2{  \n" +
                        "public static void main(String args[]){  \n" +
                        "System.out.println(Integer.parseInt(\"1010\",2));  \n" +
                        "System.out.println(Integer.parseInt(\"10101\",2));  \n" +
                        "System.out.println(Integer.parseInt(\"11111\",2));  \n" +
                        "}}  \n" +
                        "\n" +
                        "\n" +
                        "Output:\n" +
                        "10\n" +
                        "21\n" +
                        "31");
                put("23", "Decimal to Binary:\n" +
                        "\n" +
                        "public class DecimalToBinaryExample1{  \n" +
                        "public static void main(String args[]){  \n" +
                        "System.out.println(Integer.toBinaryString(10));  \n" +
                        "System.out.println(Integer.toBinaryString(21));  \n" +
                        "System.out.println(Integer.toBinaryString(31));  \n" +
                        "}}  \n" +
                        "\n" +
                        "\n" +
                        "Output:\n" +
                        "1010\n" +
                        "10101\n" +
                        "11111");
                put("24", "Decimal to Hex:\n" +
                        "\n" +
                        "public class DecimalToHexExample1{  \n" +
                        "public static void main(String args[]){  \n" +
                        "System.out.println(Integer.toHexString(10));  \n" +
                        "System.out.println(Integer.toHexString(15));  \n" +
                        "System.out.println(Integer.toHexString(289));  \n" +
                        "}}  \n" +
                        "\n" +
                        "\n" +
                        "Output:\n" +
                        "a\n" +
                        "f\n" +
                        "121");
                put("25", "Hex to Decimal:\n" +
                        "\n" +
                        "public class HexToDecimalExample2{  \n" +
                        "public static void main(String args[]){  \n" +
                        "System.out.println(Integer.parseInt(\"a\",16));  \n" +
                        "System.out.println(Integer.parseInt(\"f\",16));  \n" +
                        "System.out.println(Integer.parseInt(\"121\",16));  \n" +
                        "}}  \n" +
                        "\n" +
                        "\n" +
                        "Output:\n" +
                        "10\n" +
                        "15\n" +
                        "289\n");
                put("26", "Octal to Decimal:\n" +
                        "\n" +
                        "public class OctalToDecimalExample1{  \n" +
                        "public static void main(String args[]){  \n" +
                        "//Declaring an octal number  \n" +
                        "String octalString=\"121\";  \n" +
                        "//Converting octal number into decimal  \n" +
                        "int decimal=Integer.parseInt(octalString,8);  \n" +
                        "//Printing converted decimal number  \n" +
                        "System.out.println(decimal);  \n" +
                        "}}  \n" +
                        "\n" +
                        "\n" +
                        "Output: 81");
                put("27", "Constructor Example:\n" +
                        "\n" +
                        "class Student4{  \n" +
                        "    int id;  \n" +
                        "    String name;  \n" +
                        "    //creating a parameterized constructor  \n" +
                        "    Student4(int i,String n){  \n" +
                        "    id = i;  \n" +
                        "    name = n;  \n" +
                        "    }  \n" +
                        "    //method to display the values  \n" +
                        "    void display(){System.out.println(id+\" \"+name);}  \n" +
                        "   \n" +
                        "    public static void main(String args[]){  \n" +
                        "    //creating objects and passing values  \n" +
                        "    Student4 s1 = new Student4(111,\"Karan\");  \n" +
                        "    Student4 s2 = new Student4(222,\"Aryan\");  \n" +
                        "    //calling method to display the values of object  \n" +
                        "    s1.display();  \n" +
                        "    s2.display();  \n" +
                        "   }  \n" +
                        "}  \n" +
                        "\n" +
                        "\n" +
                        "Output:\n" +
                        "111 Karan\n" +
                        "222 Aryan");
                put("28", "Thread Example:\n" +
                        "\n" +
                        "class Count extends Thread\n" +
                        "{\n" +
                        "   Count()\n" +
                        "   {\n" +
                        "     super(\"my extending thread\");\n" +
                        "     System.out.println(\"my thread created\" + this);\n" +
                        "     start();\n" +
                        "   }\n" +
                        "   public void run()\n" +
                        "   {\n" +
                        "     try\n" +
                        "     {\n" +
                        "        for (int i=0 ;i<10;i++)\n" +
                        "        {\n" +
                        "           System.out.println(\"Printing the count \" + i);\n" +
                        "           Thread.sleep(1000);\n" +
                        "        }\n" +
                        "     }\n" +
                        "     catch(InterruptedException e)\n" +
                        "     {\n" +
                        "        System.out.println(\"my thread interrupted\");\n" +
                        "     }\n" +
                        "     System.out.println(\"My thread run is over\" );\n" +
                        "   }\n" +
                        "}\n" +
                        "class ExtendingExample\n" +
                        "{\n" +
                        "   public static void main(String args[])\n" +
                        "   {\n" +
                        "      Count cnt = new Count();\n" +
                        "      try\n" +
                        "      {\n" +
                        "         while(cnt.isAlive())\n" +
                        "         {\n" +
                        "           System.out.println(\"Main thread will be alive till the child thread is live\");\n" +
                        "           Thread.sleep(1500);\n" +
                        "         }\n" +
                        "      }\n" +
                        "      catch(InterruptedException e)\n" +
                        "      {\n" +
                        "        System.out.println(\"Main thread interrupted\");\n" +
                        "      }\n" +
                        "      System.out.println(\"Main thread's run is over\" );\n" +
                        "   }\n" +
                        "}\n" +
                        "\n" +
                        "\n" +
                        "Output:\n" +
                        "Main thread will be alive till the child thread is live\n" +
                        "Printing the count 0\n" +
                        "Printing the count 1\n" +
                        "Main thread will be alive till the child thread is live\n" +
                        "Printing the count 2\n" +
                        "Main thread will be alive till the child thread is live\n" +
                        "Printing the count 3\n" +
                        "Printing the count 4\n" +
                        "Main thread will be alive till the child thread is live\n" +
                        "Printing the count 5\n" +
                        "Main thread will be alive till the child thread is live\n" +
                        "Printing the count 6\n" +
                        "Printing the count 7\n" +
                        "Main thread will be alive till the child thread is live\n" +
                        "Printing the count 8\n" +
                        "Main thread will be alive till the child thread is live\n" +
                        "Printing the count 9\n" +
                        "mythread run is over\n" +
                        "Main thread run is over");
                put("29", "Finally Example:\n" +
                        "\n" +
                        "class GFG \n" +
                        "{ \n" +
                        "    public static void main (String[] args)  \n" +
                        "    { \n" +
                        "          \n" +
                        "        // array of size 4. \n" +
                        "        int[] arr = new int[4]; \n" +
                        "          \n" +
                        "        try\n" +
                        "        { \n" +
                        "            int i = arr[4]; \n" +
                        "                  \n" +
                        "            // this statement will never execute \n" +
                        "            // as exception is raised by above statement \n" +
                        "            System.out.println(\"Inside try block\"); \n" +
                        "        } \n" +
                        "          \n" +
                        "        catch(ArrayIndexOutOfBoundsException ex) \n" +
                        "        { \n" +
                        "            System.out.println(\"Exception caught in catch block\"); \n" +
                        "        } \n" +
                        "          \n" +
                        "        finally\n" +
                        "        { \n" +
                        "            System.out.println(\"finally block executed\"); \n" +
                        "        } \n" +
                        "          \n" +
                        "        // rest program will be executed \n" +
                        "        System.out.println(\"Outside try-catch-finally clause\"); \n" +
                        "    } \n" +
                        "} \n" +
                        "\n" +
                        "\n" +
                        "Output:\n" +
                        "Exception caught in catch block\n" +
                        "finally block executed\n" +
                        "Outside try-catch-finally clause");
                put("30", "User Defined Exception:\n" +
                        "\n" +
                        "class MyException extends Exception\n" +
                        "  {\n" +
                        "   private int ex;\n" +
                        "   MyException(int a)\n" +
                        "   {\n" +
                        "    ex=a;\n" +
                        "   }\n" +
                        "   public String toString()\n" +
                        "   {\n" +
                        "    return \"MyException[\" + ex +\"] is less than zero\";\n" +
                        "   }\n" +
                        "  }\n" +
                        "\n" +
                        "  class Test\n" +
                        "  {\n" +
                        "   static void sum(int a,int b) throws MyException\n" +
                        "   {\n" +
                        "    if(a<0)\n" +
                        "    {\n" +
                        "     throw new MyException(a); //calling constructor of user-defined exception class\n" +
                        "    }\n" +
                        "    else\n" +
                        "    {\n" +
                        "     System.out.println(a+b);\n" +
                        "    }\n" +
                        "   }\n" +
                        "\n" +
                        "   public static void main(String[] args)\n" +
                        "   {\n" +
                        "    try\n" +
                        "    {\n" +
                        "     sum(-10, 10);\n" +
                        "    }\n" +
                        "    catch(MyException me)\n" +
                        "    {\n" +
                        "     System.out.println(me); //it calls the toString() method of user-defined Exception\n" +
                        "    }\n" +
                        "   }\n" +
                        " }\n" +
                        "\n" +
                        "\n" +
                        "Output:\n" +
                        "MyException[-10] is less than zero");
                put("31", "Palindrome String:\n" +
                        "\n" +
                        "class ChkPalindrome\n" +
                        "{\n" +
                        "   public static void main(String args[])\n" +
                        "   {\n" +
                        "      String str, rev = \"\";\n" +
                        "      Scanner sc = new Scanner(System.in);\n" +
                        " \n" +
                        "      System.out.println(\"Enter a string:\");\n" +
                        "      str = sc.nextLine();\n" +
                        " \n" +
                        "      int length = str.length();\n" +
                        " \n" +
                        "      for ( int i = length - 1; i >= 0; i-- )\n" +
                        "         rev = rev + str.charAt(i);\n" +
                        " \n" +
                        "      if (str.equals(rev))\n" +
                        "         System.out.println(str+\" is a palindrome\");\n" +
                        "      else\n" +
                        "         System.out.println(str+\" is not a palindrome\");\n" +
                        " \n" +
                        "   }\n" +
                        "}\n" +
                        "\n" +
                        "\n" +
                        "Output:\n" +
                        "Enter a string:\n" +
                        "radar\n" +
                        "\n" +
                        "radar is a palindrome");
                put("32", "");


            }});

        }
    };




}
