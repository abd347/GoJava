package com.example.abdul.gojava.database.init;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ContentLoader {
    public static void topicFillData(List<String> Chapter, Map<String,List<String>> topics)
    {
        Chapter.add("1 Introduction");
        Chapter.add("2 Setup & Basic Program");
        Chapter.add("3 Variables & Data types");
        Chapter.add("4 Operators & Expression");
        Chapter.add("5 Flow Control");
        Chapter.add("6 Classes,Objects & Methods");
        Chapter.add("7 Array,String,Vector");
        Chapter.add("8 Interfaces");
        Chapter.add("9 Packages");
        Chapter.add("10 Multithreaded Programming");
        Chapter.add("11 Error & Exceptions");
        Chapter.add("12 File Management");




        List<String> Intro=new ArrayList<>();
        List<String> Setup=new ArrayList<>();
        List<String> var=new ArrayList<>();
        List<String> oper=new ArrayList<>();
        List<String> flow=new ArrayList<>();
        List<String> clas=new ArrayList<>();
        List<String> arr=new ArrayList<>();
        List<String> inter=new ArrayList<>();
        List<String> pack=new ArrayList<>();
        List<String> multi=new ArrayList<>();
        List<String> err=new ArrayList<>();
        List<String> fil=new ArrayList<>();

        Intro.add("1.1 Intro");
        Intro.add("1.2 Features");
        Intro.add("1.3 Pros and Cons");

        Setup.add("2.1 Environment Setup");
        Setup.add("2.2 First Program");

        var.add("3.1 Variables");
        var.add("3.2 Data type");
        var.add("3.3 Variable scope");
        var.add("3.4 Typecasting");

        oper.add("4.1 Operators");
        oper.add("4.2 Expression");
        oper.add("4.3 Operator precedence");

        flow.add("5.1 If Statement");
        flow.add("5.2 Switch Statement");
        flow.add("5.3 While Statement");
        flow.add("5.4 Do While Statement");
        flow.add("5.5 For Statement");


        clas.add("6.1 Classes basis");
        clas.add("6.2 Classes Objects");
        clas.add("6.3 Constructors");
        clas.add("6.4 Method Overloading");
        clas.add("6.5 Method Overriding");
        clas.add("6.6 Static Keyword");
        clas.add("6.7 Inheritance");
        clas.add("6.8 Types of Inheritance");
        clas.add("6.9 Final keyword");
        clas.add("6.10 Abstraction");

        arr.add("7.1 Arrays");
        arr.add("7.2 String");
        arr.add("7.3 Vectors");
        arr.add("7.4 Wrapper Class");

        inter.add("8.1 Defining Interfaces");
        inter.add("8.2 Extending Interfaces");
        inter.add("8.3 Implementing Interfaces");
        inter.add("8.4 Accessing Interfaces");

        pack.add("9.1 Introduction to Packages");
        pack.add("9.2 Java API Packages");
        pack.add("9.3 System Packages");

        multi.add("10.1 Creating Thread");
        multi.add("10.2 Stopping & blocking");
        multi.add("10.3 Life Cycle");
        multi.add("10.4 Exception & priority");
        multi.add("10.5 Synchronization");
        multi.add("10.6 Runnable Interface");

        err.add("11.1 Exceptions");
        err.add("11.2 Try Catch");
        err.add("11.3 Custom Exception");

        fil.add("12.1 Stream Classes");
        fil.add("12.2 Byte Stream");
        fil.add("12.3 Character Stream");
        fil.add("12.4 Standard Stream");
        fil.add("12.5 File");
        fil.add("12.6 Directory");

        topics.put(Chapter.get(0),Intro);
        topics.put(Chapter.get(1),Setup);
        topics.put(Chapter.get(2),var);
        topics.put(Chapter.get(3),oper);
        topics.put(Chapter.get(4),flow);
        topics.put(Chapter.get(5),clas);
        topics.put(Chapter.get(6),arr);
        topics.put(Chapter.get(7),inter);
        topics.put(Chapter.get(8),pack);
        topics.put(Chapter.get(9),multi);
        topics.put(Chapter.get(10),err);
        topics.put(Chapter.get(11),fil);




    }
    public static void qaFillData(List<String> Question)
    {

        Question.add("1 List any five features of Java?");
        Question.add("2 Why is Java Architectural Neutral?");
        Question.add("3 What is JIT compiler?");
        Question.add("4 Define Class?");
        Question.add("5 Why Java is platform independent?");
        Question.add("6 Why java is not 100% Object-oriented?");
        Question.add("7 What are constructors in Java?");
        Question.add("8 What is Singleton class?");
        Question.add("9 What's the purpose of Static methods and static variables?");
        Question.add("10 What is data encapsulation and what's its significance?");
        Question.add("11 What is the difference between double and float variables in Java?");
        Question.add("12 What is default switch case?");
        Question.add("13 What's the base class in Java from which all classes are derived?");
        Question.add("14 Is delete, next, main, exit or null keyword in java?");
        Question.add("15 If I don't provide any arguments on the command line, then what will the value stored in the String array passed into the main() method, empty or NULL?");
        Question.add("16 What if I write static public void instead of public static void?");
        Question.add("17 What is the default value of the local variables?");
        Question.add("18 What is an object?");
        Question.add("19 What will be the initial value of an object reference which is defined as an instance variable?");
        Question.add("20 What are the types of constructors are used in Java?");
        Question.add("21 What is the purpose of a default constructor?");
        Question.add("22 Does constructor return any value?");
        Question.add("23 Can you make a constructor final?");
        Question.add("24 Can we overload the constructors?");
        Question.add("25 What is the static method?");
        Question.add("26 Why is the main method static?");
        Question.add("27 Can we execute a program without main() method?");
        Question.add("28 What is the static block?");
        Question.add("29 What if the static modifier is removed from the signature of the main method?");
        Question.add("30 Can we make constructors static?");
        Question.add("31 Can we make the abstract methods static in Java?");
        Question.add("32 What is this keyword in java?");
        Question.add("33 Can we assign the reference to this variable?");
        Question.add("34 How can constructor chaining be done using this keyword?");
        Question.add("35 Which class is the superclass for all the classes?");
        Question.add("36 Why does Java not support pointers?");
        Question.add("37 What is super in java?");
        Question.add("38 What is object cloning?");
        Question.add("39 What is method overloading?");
        Question.add("40 Why is method overloading not possible by changing the return type in java?");



    }

}
