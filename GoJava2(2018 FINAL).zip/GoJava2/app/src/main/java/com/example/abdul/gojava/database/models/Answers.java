package com.example.abdul.gojava.database.models;

public class Answers {
    public  static  final String TABLE_NAME="answer_table";

    public static final String PAGE="page_name";
    public static final String ROW="row_id";
    public static final String ANSWER="data";

    private String row_id;
    private String page_name;
    private String answer;


    public Answers(String row_id, String page_name, String answer) {
        this.row_id = row_id;
        this.page_name = page_name;
        this.answer = answer;
    }



    public String getAnswer() {
        return answer;
    }

}
